package analogy.bsets;

import analogy.prediction.Logistic;

import java.util.HashSet;
import java.util.Arrays;
import java.util.Random;
import java.util.Hashtable;
import java.io.BufferedReader;
import java.io.FileReader;

/**
 * Similar in principle to Bayesian sets. However, instead of being based
 * on a prior, it takes the predictions of a logistic classifier with
 * randomly selected negative pairs.
 */

public class RelationalRandomSetsPair {

    int     numObjects;
    int     classes[], relations[][], numVars;
    double  allData[][], allDataNeg[][], queryData[][];
    double  paramPriorMean[];
    String  priorsFileName;
    int     occurrences[], occurrencesLength;
    int     numRelations;

    String  objectNames[];

    Hashtable<Integer, Hashtable<Integer, Integer>> relationsIndex;

    int    numNegativeSamples, indices[][];
    Random r;

    public RelationalRandomSetsPair(int numObjects, double allData[][], double allDataNeg[][], int relations[][],
                                    String priorsFileName,
                                    Hashtable<Integer, Hashtable<Integer, Integer>> relationsIndex,
                                    String objectNames[], int numNegativeSamples, Random r) {
        this.numObjects = numObjects;
        this.allData = allData;
        this.allDataNeg = allDataNeg;
        this.relations = relations;
        this.relationsIndex = relationsIndex;
        this.numVars = allData[0].length;
        this.objectNames = objectNames;
        this.numRelations = 0;
        for (int i = 0; i < this.numObjects; i++)
            this.numRelations += this.relations[i].length;
        this.numNegativeSamples = numNegativeSamples;
        this.priorsFileName = priorsFileName;
        this.r = r;
    }

    /**
     * The 'negative' pairs are selected from the linked pairs.
     */

    public double[][] selectNegativeData() {
        double negData[][] = new double[this.numNegativeSamples][];
        for (int i = 0; i < this.numNegativeSamples; i++)
            negData[i] = this.allDataNeg[this.r.nextInt(this.allDataNeg.length)];
        return negData;
    }

    public double[][] selectPositiveData(int size) {
        double posData[][] = new double[size][];
        for (int i = 0; i < size; i++)
            posData[i] = this.allData[this.r.nextInt(this.allData.length)];
        return posData;
    }

    public double[][] indicesToData(int points[][]) {
        double output[][] = new double[points.length][];
        for (int i = 0; i < output.length; i++) {
            int d1 = points[i][0], d2 = points[i][1];
            Hashtable<Integer, Integer> idx1 = this.relationsIndex.get(d1);
            if (idx1 == null)
                return null;
            Integer idx2 = this.relationsIndex.get(d1).get(d2);
            if (idx2 == null)
                throw new RuntimeException("Invalid pair!");
            if (Double.isNaN(this.allData[idx2][0]))
                throw new RuntimeException("Invalid pair!");
            output[i] = this.allData[idx2];
        }
        return output;
    }

    protected double[] buildDataPoint(int d1, int d2) {
        Hashtable<Integer, Integer> idx1 = this.relationsIndex.get(d1);
        if (idx1 == null)
            return null;
        Integer idx2 = this.relationsIndex.get(d1).get(d2);
        if (idx2 == null)
            return null;
        if (Double.isNaN(this.allData[idx2][0]))
            return null;
        return this.allData[idx2];
    }

    public int[][] query(int input[][], boolean allowableTypeI[], boolean allowableTypeII[], HashSet allowablePairs, boolean allowedRows[]) {
        //PART I: calculate variational posterior of the parameters for the set containing only the elements
        //given as input
        this.indices = new int[input.length][2];
        this.classes = new int[input.length + this.numNegativeSamples];
        for (int i = 0; i < input.length; i++) {
            this.classes[i] = 1;
            this.indices[i][0] = input[i][0]; this.indices[i][1] = input[i][1];
        }
        double queryDataPos[][] = indicesToData(this.indices);
        double queryDataNeg[][] = selectNegativeData();
        for (int i = 0; i < this.numNegativeSamples; i++)
            this.classes[input.length + i] = 0;
        this.queryData = new double[queryDataPos.length + queryDataNeg.length][];
        for (int i = 0; i < queryDataPos.length; i++)
            this.queryData[i] = queryDataPos[i];
        for (int i = 0; i < queryDataNeg.length; i++)
            this.queryData[queryDataPos.length + i] = queryDataNeg[i];

        Logistic classifierQuery = new Logistic(this.queryData, this.classes, true);
        classifierQuery.train();

        queryDataPos = selectPositiveData(input.length);
        for (int i = 0; i < queryDataPos.length; i++)
            this.queryData[i] = queryDataPos[i];
        Logistic classifierBackground = new Logistic(this.queryData, this.classes, true);
        classifierBackground.train();

        //initializePriorsFromFile();

        //System.out.println("Query data:");
        //for (int i = 0; i < this.queryData.length; i++) {
        //    for (int v = 0; v < this.queryData[i].length; v++)
        //       System.out.print(this.queryData[i][v] + " ");
        //    System.out.println(); System.out.println();
        //}

        //PART II: calculate score for each pair
        int    count = 0;
        Triple scores[] = new Triple[this.numRelations];
        //int    relationCount = 0;
        for (int i = 0; i < this.numObjects; i++) {
            if (!allowableTypeI[i])
                continue;
            for (int r = 0; r < this.relations[i].length; r++) {
                int j = this.relations[i][r];
                if (!allowableTypeII[j])
                    continue;
                if (allowablePairs != null && !allowablePairs.contains(i + "_" + j))
                    continue;
                if (this.relations[i][r] == i)
                    continue;
                double point[] = buildDataPoint(i, j);
                scores[count] = new Triple();
                scores[count].fields[1] = i; scores[count].fields[2] = r;
                scores[count].fields[0] = classifierQuery.predict(point) - classifierBackground.predict(point);
                //scores[count].fields[0] = classifierQuery.predict(point) - classifierQuery.predict(point, this.paramPriorMean);
                //System.out.println("score (" + relationCount++ + ") = " + scores[count].fields[0] + " [" + i + ", " + j + "] (out of " +
                //                   this.numRelations + " relations)");
                count++;
            }
        }
        for (int i = count; i < scores.length; i++)
            scores[i] = new Triple(-Double.MAX_VALUE, 0, 0); //compensate for relations that were skipped
        //PART III: order and return pairs
        Arrays.sort(scores, new TripleComparator());
        int topPairs[][] = new int[count][2];
        for (int i = 0; i < count; i++) {
            topPairs[i][0] = (int) scores[i].fields[1];
            topPairs[i][1] = this.relations[topPairs[i][0]][(int) scores[i].fields[2]];
        }
        return topPairs;
    }

    protected void initializePriorsFromFile() {
        this.paramPriorMean = new double[this.numVars];
        try {
            BufferedReader file = new BufferedReader(new FileReader(this.priorsFileName));
            for (int i = 0; i < this.numVars; i++) {
                String line = file.readLine();
                this.paramPriorMean[i] = Double.valueOf(line);
            }
            file.close();
        } catch(java.io.FileNotFoundException e) {
            System.out.println("Warning! Priors file not found");
            System.exit(0);
        } catch(java.io.IOException e) {
            System.out.println("Warning! Priors file IOException");
            System.exit(0);
        }
    }
}
