package analogy.bsets;

import analogy.prediction.VariationalLogisticBasic;

import java.util.*;
import java.io.BufferedReader;
import java.io.FileReader;

/**
 * Relational Bayesian Sets for analogical reasoning
 *
 * Binary output, continuous input. Assumes no sparsity of the input (as it would be the case for binary data).
 *
 * THIS VERSION ASSUMES THE DATA COMES IN PAIRS, ONLY POSITIVE PAIRS, WITHIN THE ALLDATA ARRAY. NO PRIORS ARE CHOSEN
 * HERE, BUT ONLY READ FROM A FILE. ALSO, THE RELATIONS DATA STRUCTURE IS A TWO-NESTED HASHTABLE WHICH CONTAINS POINTS
 * TO THE POSITION OF A PAIR WITHIN THE ALLDATA ARRAY.
 *
 */

public class RelationalBayesianSetsPair {

    int     numObjects;
    int     classes[], relations[][], numVars;
    double  allData[][], queryData[][];
    double  invParamPriorCov[][], paramPriorMean[];
    int     occurrences[], occurrencesLength;
    int     numRelations, relationList[][];

    double  c, originalC;
    String  priorsFileName, objectNames[];
    Random  r;

    Hashtable<Integer, Hashtable<Integer, Integer>> relationsIndex;

    public RelationalBayesianSetsPair(int numObjects, double allData[][], int relations[][], double c,
                                          String priorsFileName,
                                          Hashtable<Integer, Hashtable<Integer, Integer>> relationsIndex,
                                          String objectNames[], Random r) {
        this.numObjects = numObjects;
        this.allData = allData;
        this.relations = relations;
        this.numVars = allData[0].length;
        this.priorsFileName = priorsFileName;
        this.relationsIndex = relationsIndex;
        this.objectNames = objectNames;
        this.numRelations = 0;
        for (int i = 0; i < this.numObjects; i++)
            this.numRelations += this.relations[i].length;
        this.relationList = new int[this.numRelations][2];
        int count = 0;
        for (int i = 0; i < this.numObjects; i++)
            for (int j = 0; j < this.relations[i].length; j++) {
                this.relationList[count][0] = i;
                this.relationList[count++][1] = this.relations[i][j];
            }
        this.c = this.originalC = c;
        this.r = r;
    }

    protected double[] buildDataPoint(int d1, int d2) {
        Hashtable<Integer, Integer> idx1 = this.relationsIndex.get(d1);
        if (idx1 == null)
            return null;
        Integer idx2 = this.relationsIndex.get(d1).get(d2);
        if (idx2 == null) {
            return null;
        }
        if (Double.isNaN(this.allData[idx2][0]))
            return null;
        return this.allData[idx2];
    }

    protected Integer getDataPointIndex(int d1, int d2) {
        Hashtable<Integer, Integer> idx1 = this.relationsIndex.get(d1);
        if (idx1 == null)
            return null;
        Integer idx2 = this.relationsIndex.get(d1).get(d2);
        if (idx2 == null)
            return null;
        if (Double.isNaN(this.allData[idx2][0]))
            return null;
        return idx2;
    }

    protected Integer getDataPointPhysicalIndex(int d1, int d2) {
        Hashtable<Integer, Integer> idx1 = this.relationsIndex.get(d1);
        if (idx1 == null)
            return -1;
        Integer idx2 = this.relationsIndex.get(d1).get(d2);
        if (idx2 == null)
            return -1;
        return idx2 + 1;
    }

    public int[][] query(int input[][], boolean allowableTypeI[], boolean allowableTypeII[], HashSet allowablePairs, boolean allowedRows[]) {
        //PART I: calculate variational posterior of the parameters for the set containing only the elements
        //given as input
        this.classes = new int[input.length];
        this.queryData = new double[input.length][this.numVars];
        for (int i = 0; i < this.queryData.length; i++) {
            this.classes[i] = 1;
            this.queryData[i] = buildDataPoint(input[i][0], input[i][1]);
        }
        //System.out.println("Initializing priors");
        initializePriorsFromFile();
        VariationalLogisticBasic inputSet = null; //double bestScore = -Double.MAX_VALUE;
        double diagonalInvParamPriorCov[] = new double[this.invParamPriorCov.length];
        for (int i = 0; i < diagonalInvParamPriorCov.length; i++)
            diagonalInvParamPriorCov[i] = this.invParamPriorCov[i][i];
        VariationalLogisticBasic inputSetT =
                new VariationalLogisticBasic(this.queryData, this.classes, this.paramPriorMean, this.invParamPriorCov, this.c, this.r);
        inputSetT.updatePosterior();
        inputSet = inputSetT;

        VariationalLogisticBasic background =
                new VariationalLogisticBasic(null, null, this.paramPriorMean, this.invParamPriorCov, this.c, this.r);
        //PART II: calculate score for each pair
        int    count = 0;//, nullCount = 0, naCount = 0;
        Triple scores[] = new Triple[this.numRelations];
        double inputPair[] = new double[this.numVars];
        for (int i = 0; i < this.numObjects; i++) {
            if (!allowableTypeI[i])
                continue;
            for (int r = 0; r < this.relations[i].length; r++) {
                int j = this.relations[i][r];
                if (!allowableTypeII[j])
                    continue;
                if (allowablePairs != null && !allowablePairs.contains(i + "_" + j))
                    continue;
                Integer rowIndex = getDataPointIndex(i, j);
                if (allowedRows != null && (rowIndex == null || !allowedRows[rowIndex])) {
                    //System.out.println("* NOT ALLOWED * " + ++naCount + "[" + getDataPointPhysicalIndex(i, j) + "]");
                    continue;
                }
                if (this.relations[i][r] == i)
                    continue;
                inputPair = buildDataPoint(i, j);
                if (inputPair == null) {
                    //System.out.println("* NULL * " + ++nullCount);
                    continue;
                }
                double score1 = inputSet.logPredictiveBound(inputPair, 1);
                double score2 = background.logPredictiveBound(inputPair, 1);
                scores[count] = new Triple();
                scores[count].fields[1] = i; scores[count].fields[2] = r;
                scores[count].fields[0] = score1 - score2;
                //System.out.println("score (" + getDataPointPhysicalIndex(i, j) + ") = " + scores[count].fields[0] + " [" + i + ", " + j + "] (out of " +
                //                   this.numRelations + " relations)");
                count++;
            }
        }
        for (int i = count; i < scores.length; i++)
            scores[i] = new Triple(-Double.MAX_VALUE, 0, 0); //compensate for relations that were skipped
        //PART III: order and return pairs
        Arrays.sort(scores, new TripleComparator());
        int topPairs[][] = new int[count][2];
        for (int i = 0; i < count; i++) {
            topPairs[i][0] = (int) scores[i].fields[1];
            topPairs[i][1] = this.relations[topPairs[i][0]][(int) scores[i].fields[2]];
        }
        return topPairs;
    }

    public int[][] queryByCosine(int input[][], boolean allowableTypeI[], boolean allowableTypeII[], HashSet allowablePairs, boolean allowedRows[]) {
        this.classes = new int[input.length];
        this.queryData = new double[input.length][this.numVars];
        for (int i = 0; i < this.queryData.length; i++) {
            this.classes[i] = 1;
            this.queryData[i] = buildDataPoint(input[i][0], input[i][1]);
        }
        //PART II: calculate score for each pair
        int    count = 0;
        Triple scores[] = new Triple[this.numRelations];
        initializePriorsFromFile();
        for (int i = 0; i < this.numObjects; i++) {
            if (!allowableTypeI[i])
                continue;
            for (int r = 0; r < this.relations[i].length; r++) {
                int j = this.relations[i][r];
                if (!allowableTypeII[j])
                    continue;
                if (this.relations[i][r] == i)
                    continue;
                if (allowablePairs != null && !allowablePairs.contains(i + "_" + j))
                    continue;
                Integer rowIndex = getDataPointIndex(i, j);
                if (allowedRows != null && (rowIndex == null || !allowedRows[rowIndex]))
                    continue;
                double inputPair[] = buildDataPoint(i,this.relations[i][r]);
                if (inputPair == null)
                    continue;
                double score = 0.;
                for (int q = 0; q < this.queryData.length; q++) {
                    double partialScore = 0., norm1 = 0., norm2 = 0.;
                    for (int v = 0; v < this.numVars - 1; v++)  {
                        norm1 += inputPair[v] * inputPair[v];
                        norm2 += this.queryData[q][v] * this.queryData[q][v];
                        partialScore += inputPair[v] * this.queryData[q][v];
                    }
                    score += partialScore / Math.sqrt(norm1 * norm2);
                }
                scores[count] = new Triple();
                scores[count].fields[1] = i; scores[count].fields[2] = r;
                scores[count++].fields[0] = score;
            }
        }
        for (int i = count; i < scores.length; i++)
            scores[i] = new Triple(-Double.MAX_VALUE, 0, 0); //compensate for relations that were skipped
        //PART III: order and return pairs
        Arrays.sort(scores, new TripleComparator());
        int topPairs[][] = new int[count][2];
        for (int i = 0; i < count; i++) {
            topPairs[i][0] = (int) scores[i].fields[1];
            topPairs[i][1] = this.relations[topPairs[i][0]][(int) scores[i].fields[2]];
        }
        return topPairs;
    }

    public int[][] queryByNearestNeighbors(int input[][], boolean allowableTypeI[], boolean allowableTypeII[], HashSet allowablePairs, boolean allowedRows[]) {
        double mean[] = new double[this.numVars - 1];
        for (int i = 0; i < mean.length; i++)
            mean[i] = 0.;
        for (int d = 0; d < this.allData.length; d++)
            for (int i = 0; i < mean.length; i++)
                mean[i] += this.allData[d][i];
        for (int i = 0; i < mean.length; i++)
             mean[i] /= this.allData.length;

        this.classes = new int[input.length];
        this.queryData = new double[input.length][this.numVars];
        for (int i = 0; i < this.queryData.length; i++) {
            this.classes[i] = 1;
            this.queryData[i] = buildDataPoint(input[i][0], input[i][1]);
        }
        //PART II: calculate score for each pair
        int    count = 0;
        Triple scores[] = new Triple[this.numRelations];
        initializePriorsFromFile();
        for (int i = 0; i < this.numObjects; i++) {
            if (!allowableTypeI[i])
                continue;
            for (int r = 0; r < this.relations[i].length; r++) {
                int j = this.relations[i][r];
                if (!allowableTypeII[j])
                    continue;
                if (this.relations[i][r] == i)
                    continue;
                if (allowablePairs != null && !allowablePairs.contains(i + "_" + j))
                    continue;
                Integer rowIndex = getDataPointIndex(i, j);
                if (allowedRows != null && (rowIndex == null || !allowedRows[rowIndex]))
                    continue;
                double inputPair[] = buildDataPoint(i, this.relations[i][r]);
                if (inputPair == null)
                    continue;
                double score = 0.;
                for (int q = 0; q < this.queryData.length; q++) {
                    double partialScore = 0.;
                    for (int v = 0; v < this.numVars - 1; v++)  {
                        partialScore += (inputPair[v] - this.queryData[q][v]) * (inputPair[v] - this.queryData[q][v]);
                    }
                    score += partialScore;
                }
                scores[count] = new Triple();
                scores[count].fields[1] = i; scores[count].fields[2] = r;
                scores[count++].fields[0] = score;
            }
        }
        for (int i = count; i < scores.length; i++)
            scores[i] = new Triple(-Double.MAX_VALUE, 0, 0); //compensate for relations that were skipped
        //PART III: order and return pairs
        Arrays.sort(scores, new TripleComparator());
        int topPairs[][] = new int[count][2];
        for (int i = 0; i < count; i++) {
            topPairs[i][0] = (int) scores[i].fields[1];
            topPairs[i][1] = this.relations[topPairs[i][0]][(int) scores[i].fields[2]];
        }
        return topPairs;
    }

    protected void initializePriorsFromFile() {
        //System.out.println("...reading priors from file...");
        this.invParamPriorCov = new double[this.numVars][this.numVars];
        this.paramPriorMean = new double[this.numVars];
        try {
            BufferedReader file = new BufferedReader(new FileReader(this.priorsFileName));

            for (int i = 0; i < this.numVars; i++) {
                String line = file.readLine();
                this.paramPriorMean[i] = Double.valueOf(line);
            }
            file.close();
            file = new BufferedReader(new FileReader(this.priorsFileName + ".cov"));
            for (int i = 0; i < this.numVars; i++) {
                String line = file.readLine();
                String values[] = line.split(" ");
                for (int j = 0; j < this.numVars; j++)
                     this.invParamPriorCov[i][j] = Double.valueOf(values[j]) * this.c;
            }
            file.close();
        } catch(java.io.FileNotFoundException e) {
            System.out.println("Warning! Priors file not found");
            System.exit(0);
        } catch(java.io.IOException e) {
            System.out.println("Warning! Priors file IOException");
            System.exit(0);
        }
    }

}

