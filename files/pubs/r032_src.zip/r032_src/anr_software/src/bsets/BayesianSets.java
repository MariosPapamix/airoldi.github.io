package analogy.bsets;

import java.util.Arrays;
import java.util.List;

/**
 * Bayesian sets of multivariate Bernoulli variables, as in Ghahramani and Heller (2005)
 *
 * It also uses my sparse matrix representation of the relational version.
 *
 */

public class BayesianSets {

    int    data[][], numVars, N;
    double alpha[], beta[], alphaTilde[], betaTilde[], q[];

    private static final double c = 1000;
    private static final int    MINIMUM_LENGHT = 0;

    public BayesianSets(int data[][], int numVars, boolean fitH) {
        this.data = data;
        this.numVars = numVars;
        this.alpha = new double[this.numVars];
        this.beta = new double[this.numVars];
        this.alphaTilde = new double[this.numVars];
        this.betaTilde = new double[this.numVars];
        this.q = new double[this.numVars];
        this.N = this.data.length;
        if (fitH)
            fitHyperparameters();
    }

    protected void fitHyperparameters() {
        for (int j = 0; j < this.numVars; j++)
            this.alpha[j] = 0.;
        for (int d = 0; d < this.data.length; d++)
            for (int j = 0; j < this.data[d].length; j++)
                this.alpha[this.data[d][j]]++;
        for (int j = 0; j < this.numVars; j++) {
            this.beta[j] = c * (1. - this.alpha[j] / this.data.length);
            this.alpha[j] *= c / this.data.length;
        }
    }

    public double[][] query(int input[][]) {
        Triple scores[] = new Triple[this.data.length];
        this.N = input.length;
        for (int j = 0; j < this.numVars; j++) {
            this.alphaTilde[j] = this.alpha[j];
            this.betaTilde[j] = this.beta[j] + this.N;
        }
        for (int i = 0; i < input.length; i++)
            for (int v = 0; v < input[i].length; v++) {
                int j = input[i][v];
                this.alphaTilde[j]++;
                this.betaTilde[j]--;
            }
        double constant = 0.;
        for (int j = 0; j < this.numVars; j++) {
            this.q[j] = Math.log(this.alphaTilde[j]) - Math.log(this.alpha[j]) -
                        Math.log(this.betaTilde[j]) + Math.log(this.beta[j]);
            if (Double.isInfinite(q[j])) {
                System.out.println("!");
            }
            constant += Math.log(this.alpha[j] + this.beta[j]) - Math.log(this.alpha[j] + this.beta[j] + this.N) +
                        Math.log(this.betaTilde[j]) - Math.log(this.beta[j]);
        }

        for (int i = 0; i < this.data.length; i++) {
            scores[i] = new Triple();
            scores[i].fields[0] = constant;
            scores[i].fields[1] = i;
            //for (int j = 0; j < this.numVars; j++)
            //    scores[i].fields[0] += this.betaTilde[j];
            if (this.data[i].length < BayesianSets.MINIMUM_LENGHT)
                scores[i].fields[0] = -Double.MAX_VALUE;
            else
                for (int v = 0; v < this.data[i].length; v++)
                    scores[i].fields[0] += this.q[this.data[i][v]];
            //System.out.println("(" + (i + 1) + ") = " + scores[i].fields[0]);
            //System.out.println(i + ":" + scores[i].fields[0]);
        }
        //System.exit(0);
        Arrays.sort(scores, new TripleComparator());
        double topDocs[][] = new double[this.data.length][2];
        int trim = this.data.length;
        for (int i = 0; i < this.data.length; i++) {
            topDocs[i][0] = (int) scores[i].fields[1];
            topDocs[i][1] = scores[i].fields[0];
            if (scores[i].fields[0] == -Double.MAX_VALUE && trim == this.data.length) {
                trim = i;
                System.out.println("trim = " + trim);
            }
        }
        double trimmedTopDocs[][] = new double[trim][2];
        for (int i = 0; i < trim; i++)
             trimmedTopDocs[i] = topDocs[i];
        return trimmedTopDocs;
    }

    /**
     * Just return scores on the same order as the dataset
     */

    public double[] queryScore(int input[][]) {
        Triple scores[] = new Triple[this.data.length];
        this.N = input.length;
        for (int j = 0; j < this.numVars; j++) {
            this.alphaTilde[j] = this.alpha[j];
            this.betaTilde[j] = this.beta[j] + this.N;
        }
        for (int i = 0; i < input.length; i++)
            for (int v = 0; v < input[i].length; v++) {
                int j = input[i][v];
                this.alphaTilde[j]++;
                this.betaTilde[j]--;
            }
        double constant = 0.;
        for (int j = 0; j < this.numVars; j++) {
            this.q[j] = Math.log(this.alphaTilde[j]) - Math.log(this.alpha[j]) -
                        Math.log(this.betaTilde[j]) + Math.log(this.beta[j]);
            constant += Math.log(this.alpha[j] + this.beta[j]) - Math.log(this.alpha[j] + this.beta[j] + this.N) +
                        Math.log(this.betaTilde[j]) - Math.log(this.beta[j]);
        }

        for (int i = 0; i < this.data.length; i++) {
            scores[i] = new Triple();
            scores[i].fields[0] = constant;
            scores[i].fields[1] = i;
            if (this.data[i].length < BayesianSets.MINIMUM_LENGHT)
                scores[i].fields[0] = -Double.MAX_VALUE;
            else
                for (int v = 0; v < this.data[i].length; v++)
                    scores[i].fields[0] += this.q[this.data[i][v]];
            //System.out.println(i + ":" + scores[i].fields[0]);
        }
        //System.exit(0);
        double scoresOnly[] = new double[this.data.length];
        for (int i = 0; i < this.data.length; i++)
            scoresOnly[i] = scores[i].fields[0];
        return scoresOnly;
    }

    public double[][] queryWithNames(int input[][], List fileNames) {
        Triple scores[] = new Triple[this.data.length];
        this.N = input.length;
        for (int j = 0; j < this.numVars; j++) {
            this.alphaTilde[j] = this.alpha[j];
            this.betaTilde[j] = this.beta[j] + this.N;
        }
        for (int i = 0; i < input.length; i++)
            for (int v = 0; v < input[i].length; v++) {
                int j = input[i][v];
                this.alphaTilde[j]++;
                this.betaTilde[j]--;
            }
        double constant = 0.;
        for (int j = 0; j < this.numVars; j++) {
            this.q[j] = Math.log(this.alphaTilde[j]) - Math.log(this.alpha[j]) -
                        Math.log(this.betaTilde[j]) + Math.log(this.beta[j]);
            constant += Math.log(this.alpha[j] + this.beta[j]) - Math.log(this.alpha[j] + this.beta[j] + this.N) +
                        Math.log(this.betaTilde[j]) - Math.log(this.beta[j]);
        }

        for (int i = 0; i < this.data.length; i++) {
            scores[i] = new Triple();
            scores[i].fields[0] = constant;
            scores[i].fields[1] = i;
            //for (int j = 0; j < this.numVars; j++)
            //    scores[i].fields[0] += this.betaTilde[j];
            if (this.data[i].length < BayesianSets.MINIMUM_LENGHT)
                scores[i].fields[0] = -Double.MAX_VALUE;
            else
                for (int v = 0; v < this.data[i].length; v++)
                    scores[i].fields[0] += this.q[this.data[i][v]];
            System.out.println(fileNames.get(i) + ", score = " + scores[i].fields[0]);
        }
        System.exit(0);
        Arrays.sort(scores, new TripleComparator());
        double topDocs[][] = new double[this.data.length][2];
        int trim = this.data.length;
        for (int i = 0; i < this.data.length; i++) {
            topDocs[i][0] = (int) scores[i].fields[1];
            topDocs[i][1] = scores[i].fields[0];
            if (scores[i].fields[0] == -Double.MAX_VALUE && trim == this.data.length) {
                trim = i;
                System.out.println("trim = " + trim);
            }
        }
        double trimmedTopDocs[][] = new double[trim][2];
        for (int i = 0; i < trim; i++)
             trimmedTopDocs[i] = topDocs[i];
        return trimmedTopDocs;
    }

    //Do it by cosine distance
    public double[][] queryByCosine(int input[][]) {
        Triple scores[] = new Triple[this.data.length];
        for (int i = 0; i < this.data.length; i++) {
            scores[i] = new Triple();
            scores[i].fields[0] = 0.;
            scores[i].fields[1] = i;
            if (this.data[i].length < BayesianSets.MINIMUM_LENGHT)
                scores[i].fields[0] = -Double.MAX_VALUE;
            else {
                for (int u = 0; u < input.length; u++)
                    for (int v1 = 0; v1 < input[u].length; v1++)
                        for (int v2 = 0; v2 < this.data[i].length; v2++)
                            if (input[u][v1] == this.data[i][v2])
                                scores[i].fields[0]++;
            }
            System.out.println("(" + (i + 1) + ") = " + scores[i].fields[0]);
        }
        System.out.println("SORTING...");
        Arrays.sort(scores, new TripleComparator());
        double topDocs[][] = new double[this.data.length][2];
        for (int i = 0; i < this.N; i++) {
            int scIdx = scores.length - i - 1;
            topDocs[i][0] = (int) scores[scIdx].fields[1];
            topDocs[i][1] = (int) scores[scIdx].fields[0];
        }
        return topDocs;
    }

    public double[] getAlpha() {
        return this.alpha;
    }

    public double[] getBeta() {
        return this.beta;
    }

    public void setHyperparameters(double alpha[], double beta[]) {
        this.alpha = alpha;
        this.beta = beta;
    }

}
