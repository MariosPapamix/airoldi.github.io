package analogy.bsets;

import analogy.app.FeatureBuilder;
import analogy.prediction.Logistic;

import java.util.HashSet;
import java.util.Arrays;
import java.util.Random;
import java.io.BufferedReader;
import java.io.FileReader;

/**
 * Similar in principle to Bayesian sets. However, instead of being based
 * on a prior, it takes the predictions of a logistic classifier with
 * randomly selected negative pairs.
 */

public class RelationalRandomSets {

    int     numObjects;
    int     classes[], relations[][], numVars;
    double  allData[][], queryData[][];
    double  paramPriorMean[];
    String  priorsFileName;
    int     occurrences[], occurrencesLength;
    int     numRelations;

    String  objectNames[];

    int    numNegativeSamples, indices[][];
    Random r;

    public RelationalRandomSets(int numObjects, double allData[][], int relations[][],
                                    String objectNames[], int numNegativeSamples,
                                    String priorsFileName) {
        this.numObjects = numObjects;
        this.allData = allData;
        this.relations = relations;
        this.numVars = allData[0].length;
        this.objectNames = objectNames;
        this.numRelations = 0;
        for (int i = 0; i < this.numObjects; i++)
            this.numRelations += this.relations[i].length;
        this.numNegativeSamples = numNegativeSamples;
        this.priorsFileName = priorsFileName;
        this.r = new Random();
    }

    /**
     * The 'negative' pairs are selected from the linked pairs.
     */

    public int[][] selectNegativePairs() {
        int negPairs[][] = new int[this.numNegativeSamples][2];
        for (int i = 0; i < this.numNegativeSamples; i++) {
            while (true) {
                int p1 = this.r.nextInt(this.allData.length);
                int p2 = this.r.nextInt(this.allData.length);
                if (p1 < p2 && isLinked(p1, p2)) {
                    negPairs[i][0] = p1;
                    negPairs[i][1] = p2;
                    break;
                }
                if (p1 > p2 && isLinked(p2, p1)) {
                    negPairs[i][0] = p1;
                    negPairs[i][1] = p2;
                    break;
                }
            }
        }
        return negPairs;
    }

    public int[][] selectPositivePairs(int size) {
        int posPairs[][] = new int[size][2];

        int totalLinks = 0;
        for (int i = 0; i < this.numObjects; i++)
            totalLinks += this.relations[i].length;
        for (int i = 0; i < size; i++) {
            int linkChoice = this.r.nextInt(totalLinks);
            int current = 0, counted = 0;
            for (int j = 0; j < this.numObjects; j++) {
                if (this.relations[current].length + counted > linkChoice) {
                    int p1 = current;
                    int p2 = this.relations[current].length + counted - linkChoice;
                    if (p1 < p2 && isLinked(p1, p2)) {
                        posPairs[i][0] = p1;
                        posPairs[i][1] = p2;
                        break;
                    }
                    if (p1 > p2 && isLinked(p2, p1)) {
                        posPairs[i][0] = p1;
                        posPairs[i][1] = p2;
                        break;
                    }
                }
                counted += this.relations[current].length;
            }
        }
        return posPairs;
    }

    private boolean isLinked(int p1, int p2) {
        for (int i = 0; i < this.relations[p1].length; i++)
            if (this.relations[p1][i] == p2)
                return true;
        return false;
    }

    public double[][] indicesToData(int points[][]) {
        double output[][] = new double[points.length][];
        for (int i = 0; i < output.length; i++)
            output[i] = FeatureBuilder.build(FeatureBuilder.COSINE, this.allData[points[i][0]], this.allData[points[i][1]], false);
        return output;
    }

    public int[][] query(int input[][], boolean allowableTypeI[], boolean allowableTypeII[], HashSet allowablePairs, boolean allowedRows[]) {
        //PART I: calculate variational posterior of the parameters for the set containing only the elements
        //given as input
        this.indices = new int[input.length + this.numNegativeSamples][2];
        this.classes = new int[input.length + this.numNegativeSamples];
        for (int i = 0; i < input.length; i++) {
            this.classes[i] = 1;
            this.indices[i][0] = input[i][0]; this.indices[i][1] = input[i][1];
        }
        int selectionNeg[][] = selectNegativePairs();
        for (int i = 0; i < this.numNegativeSamples; i++) {
            this.classes[input.length + i] = 0;
            this.indices[input.length + i][0] = selectionNeg[i][0];
            this.indices[input.length + i][1] = selectionNeg[i][1];
        }

        this.queryData = indicesToData(this.indices);
        Logistic classifierQuery = new Logistic(this.queryData, this.classes, true);
        classifierQuery.train();

        int selectionPos[][] = selectPositivePairs(input.length);
        for (int i = 0; i < input.length; i++) {
            this.indices[i][0] = selectionPos[i][0];
            this.indices[i][1] = selectionPos[i][1];
        }
        this.queryData = indicesToData(this.indices);
        Logistic classifierBackground = new Logistic(this.queryData, this.classes, true);
        classifierBackground.train();

        //initializePriorsFromFile();

        //System.out.println("Query data:");
        //for (int i = 0; i < this.queryData.length; i++) {
        //    for (int v = 0; v < this.queryData[i].length; v++)
        //       System.out.print(this.queryData[i][v] + " ");
        //    System.out.println(); System.out.println();
        //}

        //PART II: calculate score for each pair
        int    count = 0;
        Triple scores[] = new Triple[this.numRelations];
        //int    relationCount = 0;
        for (int i = 0; i < this.numObjects; i++) {
            if (!allowableTypeI[i])
                continue;
            for (int r = 0; r < this.relations[i].length; r++) {
                int j = this.relations[i][r];
                if (!allowableTypeII[j])
                    continue;
                if (allowablePairs != null && !allowablePairs.contains(i + "_" + j))
                    continue;
                if (this.relations[i][r] == i)
                    continue;
                double point[] = FeatureBuilder.build(FeatureBuilder.COSINE, this.allData[i], this.allData[j], true);
                scores[count] = new Triple();
                scores[count].fields[1] = i; scores[count].fields[2] = r;
                scores[count].fields[0] = classifierQuery.predict(point) - classifierBackground.predict(point);
                //scores[count].fields[0] = classifierQuery.predict(point) - classifierQuery.predict(point, this.paramPriorMean);
                //System.out.println("score (" + relationCount++ + ") = " + scores[count].fields[0] + " [" + i + ", " + j + "] (out of " +
                //                   this.numRelations + " relations)");
                count++;
            }
        }
        for (int i = count; i < scores.length; i++)
            scores[i] = new Triple(-Double.MAX_VALUE, 0, 0); //compensate for relations that were skipped
        //PART III: order and return pairs
        Arrays.sort(scores, new TripleComparator());
        int topPairs[][] = new int[count][2];
        for (int i = 0; i < count; i++) {
            topPairs[i][0] = (int) scores[i].fields[1];
            topPairs[i][1] = this.relations[topPairs[i][0]][(int) scores[i].fields[2]];
        }
        return topPairs;
    }

    protected void initializePriorsFromFile() {
        this.paramPriorMean = new double[this.numVars];
        try {
            BufferedReader file = new BufferedReader(new FileReader(this.priorsFileName));
            for (int i = 0; i < this.numVars; i++) {
                String line = file.readLine();
                this.paramPriorMean[i] = Double.valueOf(line);
            }
            file.close();
        } catch(java.io.FileNotFoundException e) {
            System.out.println("Warning! Priors file not found");
            System.exit(0);
        } catch(java.io.IOException e) {
            System.out.println("Warning! Priors file IOException");
            System.exit(0);
        }
    }
}
