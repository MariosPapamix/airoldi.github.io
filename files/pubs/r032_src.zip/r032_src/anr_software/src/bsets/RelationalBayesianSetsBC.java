package analogy.bsets;

import analogy.prediction.VariationalLogisticBasic;
import analogy.app.FeatureBuilder;

import java.util.*;
import java.io.BufferedReader;
import java.io.FileReader;

/**
 * Relational Bayesian Sets for analogical reasoning
 *
 * Binary output, continuous input (hence, BC). Assumes no sparsity.
 *
 */

public class RelationalBayesianSetsBC {

    int     numObjects;
    int     classes[], relations[][], numVars, numVarsQuery;
    double  allData[][], queryData[][];
    double  invParamPriorCov[][], paramPriorMean[];
    int     occurrences[], occurrencesLength;
    int     numRelations, relationList[][];

    double  c;
    String  priorsFileName;

    boolean FEATURE_PRODUCT = true;
    Random  r;

    public RelationalBayesianSetsBC(double allData[][], int relations[][], String priorsFileName, double c, Random r) {
        this.numObjects = allData.length;
        this.allData = allData;
        this.relations = relations;
        this.numVars = allData[0].length;
        this.priorsFileName = priorsFileName;
        if (this.FEATURE_PRODUCT)
           this.numVarsQuery = 3 * numVars;
        else
           this.numVarsQuery = 2 * numVars;
        this.numRelations = 0;
        for (int i = 0; i < this.allData.length; i++)
            this.numRelations += this.relations[i].length;
        this.relationList = new int[this.numRelations][2];
        int count = 0;
        for (int i = 0; i < this.allData.length; i++)
            for (int j = 0; j < this.relations[i].length; j++) {
                this.relationList[count][0] = i;
                this.relationList[count++][1] = this.relations[i][j];
            }
        this.c = c;
        this.r = r;
    }

    protected void buildDataPoint(double buffer[], int d1, int d2) {
        System.arraycopy(this.allData[d1], 0, buffer, 0, this.numVars);
        System.arraycopy(this.allData[d2], 0, buffer, this.numVars, this.numVars);
        if (this.FEATURE_PRODUCT) {
            double norm1 = 0., norm2 = 0.;
            for (int j = 0; j < this.numVars; j++) {
                norm1 += this.allData[d1][j] * this.allData[d1][j];
                norm2 += this.allData[d2][j] * this.allData[d2][j];
            }
            norm1 = Math.sqrt(norm1); norm2 = Math.sqrt(norm2);
            for (int j = 0; j < this.numVars; j++)
                buffer[2 * this.numVars + j] = this.allData[d1][j] * this.allData[d2][j] / (norm1 * norm2);
        }
        buffer[buffer.length - 1] = 1.;
    }

    public int[][] query(int input[][], boolean allowableTypeI[], boolean allowableTypeII[]) {
        //PART I: calculate variational posterior of the parameters for the set containing only the elements
        //given as input
        this.classes = new int[input.length];
        this.queryData = new double[input.length][this.numVarsQuery + 1];
        for (int i = 0; i < this.queryData.length; i++) {
            this.classes[i] = 1;
            buildDataPoint(this.queryData[i], input[i][0], input[i][1]);
        }
        System.out.println("Initializing priors");
        if (this.priorsFileName == null)
            initializePriorsBasic();
        else
            initializePriorsFromFile();
        VariationalLogisticBasic inputSet =
                new VariationalLogisticBasic(this.queryData, this.classes, this.paramPriorMean, this.invParamPriorCov, this.c, this.r);
        inputSet.updatePosterior();
        VariationalLogisticBasic background =
                new VariationalLogisticBasic(null, null, this.paramPriorMean, this.invParamPriorCov, this.c, this.r);
        //PART II: calculate score for each pair
        int    count = 0;
        Triple scores[] = new Triple[this.numRelations];
        double inputPair[] = new double[this.numVarsQuery + 1];
        for (int i = 0; i < this.allData.length; i++) {
            if (!allowableTypeI[i])
                continue;
            for (int r = 0; r < this.relations[i].length; r++) {
                int j = this.relations[i][r];
                if (!allowableTypeII[j])
                    continue;
                if (this.relations[i][r] == i)
                    continue;
                buildDataPoint(inputPair, i, j);
                double score1 = inputSet.logPredictiveBound(inputPair, 1);
                double score2 = background.logPredictiveBound(inputPair, 1);
                scores[count] = new Triple();
                scores[count].fields[1] = i; scores[count].fields[2] = r;
                scores[count++].fields[0] = score1 - score2;
                System.out.println("score (" + count + ") = " + scores[count - 1].fields[0] + " [" + i + ", " + j + "] (out of " +
                                   this.numRelations + " relations)");

            }
        }
        for (int i = count; i < scores.length; i++)
            scores[i] = new Triple(-Double.MAX_VALUE, 0, 0); //compensate for relations that were skipped
        //PART III: order and return pairs
        Arrays.sort(scores, new TripleComparator());
        int topPairs[][] = new int[count][2];
        for (int i = 0; i < count; i++) {
            topPairs[i][0] = (int) scores[i].fields[1];
            topPairs[i][1] = this.relations[topPairs[i][0]][(int) scores[i].fields[2]];
        }
        System.out.println("c = " + this.c);
        return topPairs;
    }

    public int[][] queryAdditive(int input[][], boolean allowableTypeI[], boolean allowableTypeII[],
                                 double scoreTypeI[], double scoreTypeII[], List fileNames,
                                 boolean plain) {
        //PART I: calculate variational posterior of the parameters for the set containing only the elements
        //given as input
        this.classes = new int[input.length];
        this.queryData = new double[input.length][this.numVarsQuery + 1];
        if (this.FEATURE_PRODUCT) {
            for (int i = 0; i < this.queryData.length; i++) {
                this.classes[i] = 1;
                System.arraycopy(this.allData[input[i][0]], 0, this.queryData[i], 0, this.numVars);
                System.arraycopy(this.allData[input[i][1]], 0, this.queryData[i], this.numVars, this.numVars);
                double norm1 = 0., norm2 = 0.;
                for (int j = 0; j < this.numVars; j++) {
                    norm1 += this.allData[input[i][0]][j] * this.allData[input[i][0]][j];
                    norm2 += this.allData[input[i][1]][j] * this.allData[input[i][1]][j];
                }
                norm1 = Math.sqrt(norm1); norm2 = Math.sqrt(norm2);
                for (int j = 0; j < this.numVars; j++)
                    this.queryData[i][2 * this.numVars + j] = this.allData[input[i][0]][j] * this.allData[input[i][1]][j] /
                                                              (norm1 * norm2);
                this.queryData[i][this.queryData[i].length - 1] = 1.;
            }
        } else for (int i = 0; i < this.queryData.length; i++) {
            this.classes[i] = 1;
            System.arraycopy(this.allData[input[i][0]], 0, this.queryData[i], 0, this.numVars);
            System.arraycopy(this.allData[input[i][1]], 0, this.queryData[i], this.numVars, this.numVars);
            this.queryData[i][this.queryData[i].length - 1] = 1.;
        }
        System.out.println("Initializing priors");
        if (this.priorsFileName == null)
            initializePriorsBasic();
        else
            initializePriorsFromFile();
        VariationalLogisticBasic inputSet =
                new VariationalLogisticBasic(this.queryData, this.classes, this.paramPriorMean, this.invParamPriorCov, this.c, this.r);
        inputSet.updatePosterior();
        VariationalLogisticBasic background =
                new VariationalLogisticBasic(null, null, this.paramPriorMean, this.invParamPriorCov, this.c, this.r);
        //PART II: calculate score for each pair
        int    count = 0;
        Triple scores[] = new Triple[this.numRelations];
        for (int i = 0; i < this.allData.length; i++) {
            if (!allowableTypeI[i])
                continue;
            for (int r = 0; r < this.relations[i].length; r++) {
                int j = this.relations[i][r];
                if (!allowableTypeII[j])
                    continue;
                if (this.relations[i][r] == i)
                    continue;
                double inputPair[] = new double[this.numVarsQuery + 1];
                System.arraycopy(this.allData[i], 0, inputPair, 0, this.numVars);
                System.arraycopy(this.allData[j], 0, inputPair, this.numVars, this.numVars);
                if (this.FEATURE_PRODUCT) {
                    double norm1 = 0., norm2 = 0.;
                    for (int k = 0; k < this.numVars; k++) {
                        norm1 += this.allData[i][k] * this.allData[i][k];
                        norm2 += this.allData[j][k] * this.allData[j][k];
                    }
                    norm1 = Math.sqrt(norm1); norm2 = Math.sqrt(norm2);
                    for (int k = 0; k < this.numVars; k++)
                        inputPair[2 * this.numVars + k] = this.allData[i][k] * this.allData[j][k] / (norm1 * norm2);
                }
                inputPair[inputPair.length - 1] = 1;
                double score1 = inputSet.logPredictiveBound(inputPair, 1);
                double score2 = background.logPredictiveBound(inputPair, 1);
                scores[count] = new Triple();
                scores[count].fields[1] = i; scores[count].fields[2] = r;
                scores[count].fields[0] = score1 - score2;
                if (!plain)
                   scores[count].fields[0] += scoreTypeI[i] + scoreTypeII[j];
                count++;
                System.out.println("score (" + count + ") = " + scores[count - 1].fields[0] + " [" + i + ", " + j + "] (out of " +
                                   this.numRelations + " relations)");

            }
        }
        for (int i = count; i < scores.length; i++)
            scores[i] = new Triple(-Double.MAX_VALUE, 0, 0); //compensate for relations that were skipped
        //PART III: order and return pairs
        Arrays.sort(scores, new TripleComparator());
        int topPairs[][] = new int[count][2];
        for (int i = 0; i < count; i++) {
            topPairs[i][0] = (int) scores[i].fields[1];
            topPairs[i][1] = this.relations[topPairs[i][0]][(int) scores[i].fields[2]];
        }
        return topPairs;
    }

    public int[][] queryByCosine(int input[][], boolean allowableTypeI[], boolean allowableTypeII[]) {
        this.classes = new int[input.length];
        this.queryData = new double[input.length][2 * this.numVars + 1];
        for (int i = 0; i < this.queryData.length; i++) {
            this.classes[i] = 1;
            System.arraycopy(this.allData[input[i][0]], 0, this.queryData[i], 0, this.numVars);
            System.arraycopy(this.allData[input[i][1]], 0, this.queryData[i], this.numVars, this.numVars);
            this.queryData[i][this.queryData[i].length - 1] = 1.;
        }
        //PART II: calculate score for each pair
        int    count = 0;
        Triple scores[] = new Triple[this.numRelations];
        for (int i = 0; i < this.allData.length; i++) {
            if (!allowableTypeI[i])
                continue;
            for (int r = 0; r < this.relations[i].length; r++) {
                int j = this.relations[i][r];
                if (!allowableTypeII[j])
                    continue;
                if (this.relations[i][r] == i)
                    continue;
                double inputPair[] = new double[2 * this.numVars + 1];
                System.arraycopy(this.allData[i], 0, inputPair, 0, this.numVars);
                System.arraycopy(this.allData[j], 0, inputPair, this.numVars, this.numVars);
                inputPair[inputPair.length - 1] = 1;
                double score = 0.;
                for (int q = 0; q < this.queryData.length; q++) {
                    double partialScore = 0., norm1 = 0., norm2 = 0.;
                    for (int v = 0; v < 2 * this.numVars; v++)  {
                        norm1 += inputPair[v] * inputPair[v];
                        norm2 += this.queryData[q][v] * this.queryData[q][v];
                        partialScore += inputPair[v] * this.queryData[q][v];
                    }
                    score += partialScore / Math.sqrt(norm1 * norm2);
                }
                scores[count] = new Triple();
                scores[count].fields[1] = i; scores[count].fields[2] = r;
                scores[count++].fields[0] = score;
                System.out.println("score (" + count + ") = " + scores[count - 1].fields[0] + " [" + i + ", " + j + "] (out of " +
                                   this.numRelations + " relations)");

            }
        }
        for (int i = count; i < scores.length; i++)
            scores[i] = new Triple(-Double.MAX_VALUE, 0, 0); //compensate for relations that were skipped
        //PART III: order and return pairs
        Arrays.sort(scores, new TripleComparator());
        int topPairs[][] = new int[count][2];
        for (int i = 0; i < count; i++) {
            topPairs[i][0] = (int) scores[i].fields[1];
            topPairs[i][1] = this.relations[topPairs[i][0]][(int) scores[i].fields[2]];
        }
        return topPairs;
    }

    public int[][] queryByCosine(int input[][], boolean allowableTypeI[], boolean allowableTypeII[], int binaryData[][], int numFeatures) {
        this.classes = new int[input.length];
        this.queryData = new double[input.length][];
        for (int i = 0; i < this.queryData.length; i++) {
            this.classes[i] = 1;
            this.queryData[i] = FeatureBuilder.build(FeatureBuilder.CONCAT,
                                                     binaryData[input[i][0]], binaryData[input[i][1]], numFeatures);
        }
        //PART II: calculate score for each pair
        int    count = 0;
        Triple scores[] = new Triple[this.numRelations];
        for (int i = 0; i < this.numObjects; i++) {
            if (!allowableTypeI[i])
                continue;
            for (int r = 0; r < this.relations[i].length; r++) {
                int j = this.relations[i][r];
                if (!allowableTypeII[j])
                    continue;
                if (this.relations[i][r] == i)
                    continue;
                double inputPair[] = FeatureBuilder.build(FeatureBuilder.CONCAT,
                                                     binaryData[i], binaryData[this.relations[i][r]], numFeatures);
                if (inputPair == null)
                    continue;
                double score = 0.;
                for (int q = 0; q < this.queryData.length; q++) {
                    double partialScore = 0., norm1 = 0., norm2 = 0.;
                    for (int v = 0; v < inputPair.length; v++)  {
                        norm1 += inputPair[v] * inputPair[v];
                        norm2 += this.queryData[q][v] * this.queryData[q][v];
                        partialScore += inputPair[v] * this.queryData[q][v];
                    }
                    score += partialScore / Math.sqrt(norm1 * norm2);
                }
                scores[count] = new Triple();
                scores[count].fields[1] = i; scores[count].fields[2] = r;
                scores[count++].fields[0] = score;
            }
        }
        for (int i = count; i < scores.length; i++)
            scores[i] = new Triple(-Double.MAX_VALUE, 0, 0); //compensate for relations that were skipped
        //PART III: order and return pairs
        Arrays.sort(scores, new TripleComparator());
        int topPairs[][] = new int[count][2];
        for (int i = 0; i < count; i++) {
            topPairs[i][0] = (int) scores[i].fields[1];
            topPairs[i][1] = this.relations[topPairs[i][0]][(int) scores[i].fields[2]];
        }
        return topPairs;
    }

    protected void initializePriorsBasic() {
        this.numVarsQuery++;
        this.invParamPriorCov = new double[this.numVarsQuery][this.numVarsQuery];
        this.paramPriorMean = new double[this.numVarsQuery];
        for (int i = 0; i < this.numVarsQuery; i++) {
            this.paramPriorMean[i] = 0.;
            for (int j = 0; j < this.numVarsQuery; j++)
                this.invParamPriorCov[i][j] = 0.;
            this.invParamPriorCov[i][i] = 1;
        }
        this.numVarsQuery--;
    }

    protected void initializePriorsFromFile() {
        //1. Calculate correlation matrix of the data
        this.numVarsQuery++;
        System.out.println("...reading priors from file...");
        this.invParamPriorCov = new double[this.numVarsQuery][this.numVarsQuery];
        this.paramPriorMean = new double[this.numVarsQuery];
        try {
            BufferedReader file = new BufferedReader(new FileReader(this.priorsFileName));
            for (int i = 0; i < this.numVarsQuery; i++) {
                String line = file.readLine();
                this.paramPriorMean[i] = Double.valueOf(line);
            }
            file.close();
            file = new BufferedReader(new FileReader(this.priorsFileName + ".cov"));
            for (int i = 0; i < this.numVarsQuery; i++) {
                String line = file.readLine();
                String values[] = line.split(" |\t");
                for (int j = 0; j < this.numVarsQuery; j++)
                     this.invParamPriorCov[i][j] = Double.valueOf(values[j]) * this.c;
            }
            file.close();
        } catch(java.io.FileNotFoundException e) {
            System.out.println("Warning! Priors file not found");
            System.exit(0);
        } catch(java.io.IOException e) {
            System.out.println("Warning! Priors file IOException");
            System.exit(0);
        }
        this.numVarsQuery--;
    }

    protected static double[][] correlationMatrix(double data[][]) {
        int    numVars = data[0].length;
        double variances[][] = new double[numVars][numVars];
        double mean[] = new double[numVars];
        for (int i = 0; i < numVars; i++) {
            for (int j = 0; j < numVars; j++)
                variances[i][j] = 0.;
            mean[i] = 0.;
        }
        for (int d = 0; d < data.length; d++) {
            for (int i = 0; i < numVars; i++) {
                mean[i] += data[d][i];
                for (int j = 0; j < numVars; j++)
                    variances[i][j] += data[d][i] * data[d][j];
            }
        }
        for (int i = 0; i < numVars; i++)
            mean[i] /= data.length;
        for (int i = 0; i < numVars; i++)
            for (int j = 0; j < numVars; j++)
                 variances[i][j] = variances[i][j] / data.length - mean[i] * mean[j];
        double corr[][] = new double[numVars][numVars];
        for (int i = 0; i < numVars; i++)
            for (int j = 0; j < numVars; j++)
                corr[i][j] = variances[i][j] / (Math.sqrt(variances[i][i] * variances[j][j]));
        return corr;
    }

}

class Triple {
    double fields[];

    public Triple(double a1, double a2, double a3) {
        this.fields = new double[3];
        this.fields[0] = a1; this.fields[1] = a2; this.fields[2] = a3;
    }

    public Triple() {
        this.fields = new double[3];
    }
}

class TripleComparator implements Comparator<Triple> {

    public int compare(Triple a, Triple b) {
        if (a.fields[0] > b.fields[0])
            return -1;
        if (a.fields[0] < b.fields[0])
            return 1;
        return 0;
    }

}
