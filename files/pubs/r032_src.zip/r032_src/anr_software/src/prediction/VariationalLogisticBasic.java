package analogy.prediction;

import cern.colt.matrix.linalg.Algebra;
import cern.colt.matrix.DoubleMatrix2D;
import cern.colt.matrix.impl.DenseDoubleMatrix2D;

import java.util.Random;

/**
 * Created by IntelliJ IDEA.
 * User: Ricardo Silva
 * Date: May 6, 2006
 * Time: 3:37:36 PM
 * To change this template use File | Settings | File Templates.
 */

public class VariationalLogisticBasic {

    private int MAX_ITER = 200;
    private int MAX_ITER_PRED = 50;

    double data[][];
    int    classes[], numVars;

    double paramPriorMean[], invParamPriorCov[][], paramPriorCov[][], invSigmaPriorMuPrior[];
    double paramPosteriorCov[][], invParamPosteriorCov[][], paramPosteriorSecondMoments[][];
    double paramPosteriorMean[];
    double paramPosteriorMeanAux[];

    double paramCovPointBuffer[], predictiveCov[][];

    double marginalLikelihood;
    Random r;

    double scratchPad1[][], scratchPad2[][];

    public VariationalLogisticBasic(double data[][], int classes[], double paramPriorMean[], double invParamPriorCov[][],
                                    double paramPriorCov[][], double dummy, Random r) {
        this.numVars = paramPriorMean.length;
        this.invParamPriorCov = invParamPriorCov;
        this.paramPriorCov = paramPriorCov;
        this.paramPriorMean = paramPriorMean;
        this.invSigmaPriorMuPrior = new double[this.numVars];
        this.paramPosteriorMeanAux = new double[this.numVars];
        if (data != null) {
            this.data = data;
            this.classes = classes;
            this.paramPosteriorMean = new double[this.numVars];
            this.paramPosteriorSecondMoments = new double[this.numVars][this.numVars];
            this.invParamPosteriorCov = new double[this.numVars][this.numVars];
            this.paramPosteriorCov = new double[this.numVars][this.numVars];
            this.invSigmaPriorMuPrior = new double[this.numVars];
        } else {
            this.data = new double[0][0]; updatePosterior();
            this.paramPosteriorMean = paramPriorMean;
            this.invParamPosteriorCov = invParamPriorCov;
            this.paramPosteriorCov = paramPriorCov;
        }
        this.paramCovPointBuffer = new double[this.numVars];
        this.predictiveCov = new double[this.numVars][this.numVars];
        this.scratchPad1 = new double[this.numVars][this.numVars];
        this.scratchPad2 = new double[this.numVars][this.numVars];
        this.r = r;
    }

    public void setIterations(int fitting, int predicting) {
        MAX_ITER = fitting; MAX_ITER_PRED = predicting;
    }

    public VariationalLogisticBasic(double data[][], int classes[], double paramPriorMean[], double invParamPriorCov[][],
                                    double dummy, Random r) {
        this(data, classes, paramPriorMean, invParamPriorCov, inverse(invParamPriorCov), dummy, r);
    }

    public void updatePosterior() {
        double qsi, lambdaQsi;
        double workingInvCovPrior[][] = new double[this.numVars][this.numVars];
        double workingCovPrior[][] = new double[this.numVars][this.numVars];
        double workingMeanPrior[] = new double[this.numVars];
        System.arraycopy(this.paramPriorMean, 0, workingMeanPrior, 0, this.numVars);
        for (int i = 0; i < this.numVars; i++) {
            System.arraycopy(this.invParamPriorCov[i], 0, workingInvCovPrior[i], 0, this.numVars);
            System.arraycopy(this.paramPriorCov[i], 0, workingCovPrior[i], 0, this.numVars);
        }
        for (int d = 0; d < this.data.length; d++) {
            qsi = r.nextDouble() * 10.;
            lambdaQsi = Math.tanh(qsi * 0.5) / (4. * qsi);
            for (int i = 0; i < MAX_ITER; i++) {

                for (int v1 = 0; v1 < this.numVars; v1++) {
                   this.paramCovPointBuffer[v1] = 0.;
                    for (int v2 = 0; v2 < this.numVars; v2++)
                        this.paramCovPointBuffer[v1] += workingCovPrior[v1][v2] * this.data[d][v2];
                }
                double c = 0;
                for (int v1 = 0; v1 < this.numVars; v1++)
                    c += this.data[d][v1] * this.paramCovPointBuffer[v1];
                double ratio = 2. * lambdaQsi / (1. + 2. * lambdaQsi * c);
                for (int v1 = 0; v1 < this.numVars; v1++)
                    for (int v2 = v1; v2 < this.numVars; v2++)
                        this.paramPosteriorCov[v1][v2] = this.paramPosteriorCov[v2][v1] =
                              workingCovPrior[v1][v2] - ratio * this.paramCovPointBuffer[v1] * this.paramCovPointBuffer[v2];


                for (int v1 = 0; v1 < this.numVars; v1++)
                    for (int v2 = v1; v2 < this.numVars; v2++)
                        this.invParamPosteriorCov[v1][v2] = this.invParamPosteriorCov[v2][v1] =
                                workingInvCovPrior[v1][v2] + 2. * lambdaQsi *
                                                            this.data[d][v1] * this.data[d][v2];

                for (int j = 0; j < this.numVars; j++) {
                    this.invSigmaPriorMuPrior[j] = 0.;
                    for (int k = 0; k < this.numVars; k++)
                        this.invSigmaPriorMuPrior[j] += workingInvCovPrior[j][k] * workingMeanPrior[k];
                }
                for (int v = 0; v < this.numVars; v++)
                    this.paramPosteriorMeanAux[v] = this.invSigmaPriorMuPrior[v] +
                                                    (this.classes[d] - 0.5) * this.data[d][v];
                for (int v1 = 0; v1 < this.numVars; v1++) {
                    this.paramPosteriorMean[v1] = 0.;
                    for (int v2 = 0; v2 < this.numVars; v2++)
                        this.paramPosteriorMean[v1] += this.paramPosteriorCov[v1][v2] * this.paramPosteriorMeanAux[v2];
                }
                for (int v1 = 0; v1 < this.numVars; v1++)
                    for (int v2 = v1; v2 < this.numVars; v2++)
                        this.paramPosteriorSecondMoments[v1][v2] = this.paramPosteriorSecondMoments[v2][v1] =
                             this.paramPosteriorCov[v1][v2] + this.paramPosteriorMean[v1] * this.paramPosteriorMean[v2];
                qsi = 0.;
                for (int v1 = 0; v1 < this.numVars; v1++)
                    for (int v2 = 0; v2 < this.numVars; v2++)
                        qsi += this.paramPosteriorSecondMoments[v1][v2] * this.data[d][v1] * this.data[d][v2];
                qsi = Math.sqrt(qsi);
                lambdaQsi = Math.tanh(qsi * 0.5) / (4. * qsi);
            }
            System.arraycopy(this.paramPosteriorMean, 0, workingMeanPrior, 0, this.numVars);
            for (int j = 0; j < this.numVars; j++) {
                System.arraycopy(this.invParamPosteriorCov[j], 0, workingInvCovPrior[j], 0, this.numVars);
                System.arraycopy(this.paramPosteriorCov[j], 0, workingCovPrior[j], 0, this.numVars);
            }
        }
    }

    public void updatePosteriorWithMarginal() {
        double qsi, lambdaQsi;
        double workingInvCovPrior[][] = new double[this.numVars][this.numVars];
        double workingCovPrior[][] = new double[this.numVars][this.numVars];
        double workingMeanPrior[] = new double[this.numVars];
        System.arraycopy(this.paramPriorMean, 0, workingMeanPrior, 0, this.numVars);
        System.arraycopy(this.paramPriorMean, 0, this.paramPosteriorMean, 0, this.numVars);
        for (int i = 0; i < this.numVars; i++) {
            System.arraycopy(this.invParamPriorCov[i], 0, workingInvCovPrior[i], 0, this.numVars);
            System.arraycopy(this.paramPriorCov[i], 0, workingCovPrior[i], 0, this.numVars);
            System.arraycopy(this.invParamPriorCov[i], 0, this.invParamPosteriorCov[i], 0, this.numVars);
            System.arraycopy(this.paramPriorCov[i], 0, this.paramPosteriorCov[i], 0, this.numVars);
        }

        this.marginalLikelihood = 0.;
        for (int d = 0; d < this.data.length; d++) {
            this.marginalLikelihood += logPredictiveBound(this.data[d], this.classes[d]);
            qsi = r.nextDouble() * 10.;
            lambdaQsi = Math.tanh(qsi * 0.5) / (4. * qsi);
            for (int i = 0; i < MAX_ITER; i++) {

                for (int v1 = 0; v1 < this.numVars; v1++) {
                   this.paramCovPointBuffer[v1] = 0.;
                    for (int v2 = 0; v2 < this.numVars; v2++)
                        this.paramCovPointBuffer[v1] += workingCovPrior[v1][v2] * this.data[d][v2];
                }
                double c = 0;
                for (int v1 = 0; v1 < this.numVars; v1++)
                    c += this.data[d][v1] * this.paramCovPointBuffer[v1];
                double ratio = 2. * lambdaQsi / (1. + 2. * lambdaQsi * c);
                for (int v1 = 0; v1 < this.numVars; v1++)
                    for (int v2 = v1; v2 < this.numVars; v2++)
                        this.paramPosteriorCov[v1][v2] = this.paramPosteriorCov[v2][v1] =
                              workingCovPrior[v1][v2] - ratio * this.paramCovPointBuffer[v1] * this.paramCovPointBuffer[v2];


                for (int v1 = 0; v1 < this.numVars; v1++)
                    for (int v2 = v1; v2 < this.numVars; v2++)
                        this.invParamPosteriorCov[v1][v2] = this.invParamPosteriorCov[v2][v1] =
                                workingInvCovPrior[v1][v2] + 2. * lambdaQsi *
                                                            this.data[d][v1] * this.data[d][v2];

                for (int j = 0; j < this.numVars; j++) {
                    this.invSigmaPriorMuPrior[j] = 0.;
                    for (int k = 0; k < this.numVars; k++)
                        this.invSigmaPriorMuPrior[j] += workingInvCovPrior[j][k] * workingMeanPrior[k];
                }
                for (int v = 0; v < this.numVars; v++)
                    this.paramPosteriorMeanAux[v] = this.invSigmaPriorMuPrior[v] +
                                                    (this.classes[d] - 0.5) * this.data[d][v];
                for (int v1 = 0; v1 < this.numVars; v1++) {
                    this.paramPosteriorMean[v1] = 0.;
                    for (int v2 = 0; v2 < this.numVars; v2++)
                        this.paramPosteriorMean[v1] += this.paramPosteriorCov[v1][v2] * this.paramPosteriorMeanAux[v2];
                }
                for (int v1 = 0; v1 < this.numVars; v1++)
                    for (int v2 = v1; v2 < this.numVars; v2++)
                        this.paramPosteriorSecondMoments[v1][v2] = this.paramPosteriorSecondMoments[v2][v1] =
                             this.paramPosteriorCov[v1][v2] + this.paramPosteriorMean[v1] * this.paramPosteriorMean[v2];
                qsi = 0.;
                for (int v1 = 0; v1 < this.numVars; v1++)
                    for (int v2 = 0; v2 < this.numVars; v2++)
                        qsi += this.paramPosteriorSecondMoments[v1][v2] * this.data[d][v1] * this.data[d][v2];
                qsi = Math.sqrt(qsi);
                lambdaQsi = Math.tanh(qsi * 0.5) / (4. * qsi);
            }
            System.arraycopy(this.paramPosteriorMean, 0, workingMeanPrior, 0, this.numVars);
            for (int j = 0; j < this.numVars; j++) {
                System.arraycopy(this.invParamPosteriorCov[j], 0, workingInvCovPrior[j], 0, this.numVars);
                System.arraycopy(this.paramPosteriorCov[j], 0, workingCovPrior[j], 0, this.numVars);
            }
        }
    }

    public double logMarginalBound() {
         return this.marginalLikelihood;
    }

    public double logPredictiveBound(double newPoint[], int newClass) {
        double qsi, lambdaQsi;
        double predictiveInvCov[][] = new double[this.numVars][this.numVars];
        double predictiveMean[] = new double[this.numVars];
        double predictiveSecondMoments[][] = new double[this.numVars][this.numVars];

        qsi = r.nextDouble() * 10.;
        lambdaQsi = Math.tanh(qsi * 0.5) / (4. * qsi);
        for (int i = 0; i < MAX_ITER_PRED; i++) {

            for (int v1 = 0; v1 < this.numVars; v1++) {
               this.paramCovPointBuffer[v1] = 0.;
                for (int v2 = 0; v2 < this.numVars; v2++)
                    this.paramCovPointBuffer[v1] += this.paramPosteriorCov[v1][v2] * newPoint[v2];
            }
            double c = 0;
            for (int v1 = 0; v1 < this.numVars; v1++)
                c += newPoint[v1] * this.paramCovPointBuffer[v1];
            double ratio = 2. * lambdaQsi / (1. + 2. * lambdaQsi * c);
            for (int v1 = 0; v1 < this.numVars; v1++)
                for (int v2 = v1; v2 < this.numVars; v2++)
                    this.predictiveCov[v1][v2] = this.predictiveCov[v2][v1] =
                            this.paramPosteriorCov[v1][v2] -
                                                 ratio * this.paramCovPointBuffer[v1] * this.paramCovPointBuffer[v2];
            for (int v1 = 0; v1 < this.numVars; v1++)
                for (int v2 = v1; v2 < this.numVars; v2++)
                    predictiveInvCov[v1][v2] = predictiveInvCov[v2][v1] =
                            this.invParamPosteriorCov[v1][v2] + 2. * lambdaQsi *  newPoint[v1] * newPoint[v2];

            for (int j = 0; j < this.numVars; j++) {
                this.invSigmaPriorMuPrior[j] = 0.;
                for (int k = 0; k < this.numVars; k++)
                    this.invSigmaPriorMuPrior[j] += this.invParamPosteriorCov[j][k] * this.paramPosteriorMean[k];
            }
            for (int v = 0; v < this.numVars; v++)
                this.paramPosteriorMeanAux[v] = this.invSigmaPriorMuPrior[v] + (newClass - 0.5) * newPoint[v];
            for (int v1 = 0; v1 < this.numVars; v1++) {
                predictiveMean[v1] = 0.;
                for (int v2 = 0; v2 < this.numVars; v2++)
                    predictiveMean[v1] += this.predictiveCov[v1][v2] * this.paramPosteriorMeanAux[v2];
            }
            for (int v1 = 0; v1 < this.numVars; v1++)
                for (int v2 = 0; v2 < this.numVars; v2++)
                    predictiveSecondMoments[v1][v2] = this.predictiveCov[v1][v2] + predictiveMean[v1] * predictiveMean[v2];
            qsi = 0.;
            for (int v1 = 0; v1 < this.numVars; v1++)
                for (int v2 = 0; v2 < this.numVars; v2++)
                    qsi += predictiveSecondMoments[v1][v2] * newPoint[v1] * newPoint[v2];
            qsi = Math.sqrt(qsi);
            lambdaQsi = Math.tanh(qsi * 0.5) / (4. * qsi);
        }

        double output = -Math.log(1. + Math.exp(-qsi)) - 0.5 * qsi + lambdaQsi * qsi * qsi;
        //output += 0.5 * (Math.log(determinant(this.invParamPosteriorCov)) - Math.log(determinant(predictiveInvCov)));

        double scale = 1;
        for (int i = 0; i < this.numVars; i++)
            for (int j = 0; j < this.numVars; j++) {
                this.scratchPad1[i][j] = this.invParamPosteriorCov[i][j] * scale; //Adjust scale depending on overflow/underflow
                this.scratchPad2[i][j] = predictiveInvCov[i][j] * scale;
            }
        output += 0.5 * (Math.log(determinant(this.scratchPad1)) - Math.log(determinant(this.scratchPad2)));

        if (Double.isNaN(output)) {
            System.out.println("Output NaN");
            System.exit(0);
        }

        if (Double.isInfinite(output)) {
            System.out.println("Output Infinite");
            System.exit(0);
        }

        double productAux[] = new double[this.numVars];
        for (int i = 0; i < this.numVars; i++) {
            productAux[i] = 0;
            for (int j = 0; j < this.numVars; j++)
                productAux[i] += predictiveMean[j] * predictiveInvCov[j][i];
        }
        for (int i = 0; i < this.numVars; i++)
            output += 0.5 * productAux[i] * predictiveMean[i];
        for (int i = 0; i < this.numVars; i++) {
            productAux[i] = 0;
            for (int j = 0; j < this.numVars; j++)
                productAux[i] += this.paramPosteriorMean[j] * this.invParamPosteriorCov[j][i];
        }
        for (int i = 0; i < this.numVars; i++) {
            output -= 0.5 * productAux[i] * this.paramPosteriorMean[i];
            if (Double.isNaN(output)) {
                System.out.println("Output NaN at " + i);
                System.exit(0);
            }
        }
        return output;
    }

    /**
     * Extra auxiliary methods
     */

    public int[] prediction(int test[][]) {
        int output[] = new int[test.length];
        for (int i = 0; i < test.length; i++) {
            double thetaX = 0.;
            for (int j = 0; j < test[i].length; j++)
                thetaX += this.paramPosteriorMean[test[i][j]];
            if (thetaX > 0.)
                output[i] = 1;
            else
                output[i] = 0;
        }
        return output;
    }

    public double[][] getPosteriorCov() {
        return this.paramPosteriorCov;
    }

    public double[][] getInvPosteriorCov() {
        return this.invParamPosteriorCov;
    }

    public double[] getPosteriorMean() {
        return this.paramPosteriorMean;
    }

    protected static double[][] inverse(double matrix[][]) {
        Algebra algebra = new Algebra();
        DoubleMatrix2D m = new DenseDoubleMatrix2D(matrix);
        DoubleMatrix2D result = algebra.inverse(m);
        return result.toArray();
    }

    public static double determinant(double[][] m) {
        return new Algebra().det(new DenseDoubleMatrix2D(m));
    }

}