package analogy.prediction;

import cern.colt.matrix.linalg.Algebra;
import cern.colt.matrix.DoubleMatrix2D;
import cern.colt.matrix.impl.DenseDoubleMatrix2D;
import weka.core.Instance;
import weka.core.Instances;
import weka.core.FastVector;
import weka.core.Attribute;


/**
 * This class provides a simpler interface to Weka's logistic regression procedure.
 */

public class Logistic {

    double  data[][];
    int     classes[], numVars;

    double  param[];
    boolean removeIntercept;

    weka.classifiers.functions.Logistic classifier;

    public Logistic(double data[][], int classes[], boolean removeIntercept) {
        if (removeIntercept)
            this.numVars = data[0].length - 1;
        else
            this.numVars = data[0].length;
        this.data = data;
        this.classes = classes;
        this.param = new double[this.numVars + 1];
        this.removeIntercept = removeIntercept;
    }

    /**
     * Auxiliary methods
     */

    public double[] getParams() {
        return this.param;
    }

    protected static double[][] inverse(double matrix[][]) {
        Algebra algebra = new Algebra();
        DoubleMatrix2D m = new DenseDoubleMatrix2D(matrix);
        DoubleMatrix2D result = algebra.inverse(m);
        return result.toArray();
    }

    public static double determinant(double[][] m) {
        return new Algebra().det(new DenseDoubleMatrix2D(m));
    }

    /**
     * Core methods
     */

    /**
     * Assumes input data is binary
     */

    public int[] sparseClassify(int test[][]) {
        int output[] = new int[test.length];
        for (int i = 0; i < test.length; i++) {
            double thetaX = 0.;
            for (int j = 0; j < test[i].length; j++)
                thetaX += this.param[test[i][j]];
            if (thetaX > 0.)
                output[i] = 1;
            else
                output[i] = 0;
        }
        return output;
    }

    public void train() {
        weka.classifiers.functions.Logistic logistic = new weka.classifiers.functions.Logistic();

        double fullData[][] = new double[this.data.length][this.numVars + 1];
        for (int i = 0; i < fullData.length; i++) {
            System.arraycopy(this.data[i], 0, fullData[i], 0, this.numVars);
            fullData[i][this.numVars] = this.classes[i];
        }
        FastVector attributes = new FastVector(this.numVars + 1);
        for (int i = 0; i < this.numVars; i++)
            attributes.addElement(new Attribute("X" + i));
        FastVector classValues = new FastVector(2);
        classValues.addElement("0");
        classValues.addElement("1");
        attributes.addElement(new Attribute("Class", classValues));

        Instances instances = new Instances("default", attributes, this.data.length);
        instances.setClassIndex(this.numVars);

        for (int i = 0; i < this.data.length; i++) {
            Instance instance = new Instance(1, fullData[i]);
            instance.setDataset(instances);
            instances.add(instance);
        }

        try {
            logistic.buildClassifier(instances);
            this.classifier = logistic;
            double modelCoeff[][] = logistic.coefficients();
            if (modelCoeff.length == this.numVars + 1)
                for (int i = 0; i < this.numVars + 1; i++)
                    this.param[i] = modelCoeff[i][0];
            //else
            //    System.out.println("Warning. Coefficients at zero");
        } catch (java.lang.Exception e) {
            throw new RuntimeException(e);
        }
    }

    public double predict(double input[]) {
        double inputP[];
        if (this.removeIntercept) {
            inputP = new double[input.length - 1];
            System.arraycopy(input, 0, inputP, 0, input.length - 1);
        }
        else
            inputP = input;
        Instance instance = new Instance(1, inputP);
        try {
            double distribution[] = this.classifier.distributionForInstance(instance);
            return distribution[1];
        } catch (java.lang.Exception e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * It is assumed that input[] contains an intercept term already.
     */

    public double predict(double input[], double weights[]) {
        double x = 0.;
        for (int i = 0; i < weights.length; i++)
            x += weights[i] * input[i];
        return 1. / (1. + Math.exp(-x));
    }

}