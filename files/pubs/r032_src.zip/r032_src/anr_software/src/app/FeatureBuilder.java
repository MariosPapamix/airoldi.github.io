package analogy.app;

/**
 * Creates features for the logistic classifier.
 */

public class FeatureBuilder {

    public static final int CONCAT  = 0;
    public static final int COSINE  = 1;
    public static final int COSINEX = 2;
    public static final int SUMDIFF = 3;
    public static final int INTLIKE = 4;

    public static double[] build(int type, double data1[], double data2[], boolean intercept) {
        switch (type) {
            case CONCAT:  return buildConcat(data1, data2);
            case COSINE:  return buildCosine(data1, data2, intercept);
            case COSINEX: return buildCosinex(data1, data2, intercept);
            case SUMDIFF: return buildSumDiffCosine(data1, data2, intercept);
            case INTLIKE: return buildIntegerLike(data1, data2, intercept);
            default: throw new RuntimeException("FeatureBuilder: invalid feature type!");
        }
    }

    public static double[] build(int type, int data1[], int data2[], int numFeatures) {
        switch (type) {
            case CONCAT:  return buildConcat(data1, data2, numFeatures);
            default: throw new RuntimeException("FeatureBuilder: invalid feature type!");
        }
    }

    public static double[] buildCosine(double data1[], double data2[], boolean intercept) {
        int totalLength = data1.length;
        if (intercept)
            totalLength++;
        double output[] = new double[totalLength];

        double norm1 = 0, norm2 = 0;
        for (int i = 0; i < data1.length; i++) {
            norm1 += data1[i] * data1[i];
            norm2 += data2[i] * data2[i];
        }
        norm1 = Math.sqrt(norm1); norm2 = Math.sqrt(norm2);
        for (int i = 0; i < data1.length; i++)
            output[i] = data1[i] * data2[i] / (norm1 * norm2);

        if (intercept)
            output[totalLength - 1] = 1.;

        return output;
    }

    public static double[] buildCosinex(double data1[], double data2[], boolean intercept) {
        int totalLength = 3 * data1.length;
        if (intercept)
            totalLength++;
        double output[] = new double[totalLength];

        double norm1 = 0, norm2 = 0;
        for (int i = 0; i < data1.length; i++) {
            norm1 += data1[i] * data1[i];
            norm2 += data2[i] * data2[i];
        }
        norm1 = Math.sqrt(norm1); norm2 = Math.sqrt(norm2);
        for (int i = 0; i < data1.length; i++) {
            output[i] = data1[i];
            output[data1.length + i] = data2[i];
        }
        for (int i = 0; i < data1.length; i++)
            output[2 * data1.length + i] = data1[i] * data2[i] / (norm1 * norm2);

        if (intercept)
            output[totalLength - 1] = 1.;

        return output;
    }

    public static double[] buildSumDiff(double data1[], double data2[], boolean intercept) {
        int totalLength = 2 * data1.length;
        if (intercept)
            totalLength++;
        double output[] = new double[totalLength];

        for (int i = 0; i < data1.length; i++)
            output[i] = data1[i] + data2[i];
        for (int i = data1.length; i < 2 * data1.length; i++)
            output[i] = Math.abs(data1[i - data1.length] - data2[i - data1.length]);

        if (intercept)
            output[totalLength - 1] = 1.;

        return output;
    }

    public static double[] buildCosineDiff(double data1[], double data2[], boolean intercept) {
        int totalLength = 2 * data1.length;
        if (intercept)
            totalLength++;
        double output[] = new double[totalLength];

        double norm1 = 0, norm2 = 0;
        for (int i = 0; i < data1.length; i++) {
            norm1 += data1[i] * data1[i];
            norm2 += data2[i] * data2[i];
        }
        norm1 = Math.sqrt(norm1); norm2 = Math.sqrt(norm2);
        for (int i = 0; i < data1.length; i++)
            output[i] = data1[i] * data2[i] / (norm1 * norm2);

        for (int i = 0; i < data1.length; i++)
            output[data1.length + i] = Math.abs(data1[i] - data2[i]);

        if (intercept)
            output[totalLength - 1] = 1.;

        return output;
    }

    public static double[] buildSumDiffCosine(double data1[], double data2[], boolean intercept) {
        int totalLength = 3 * data1.length;
        if (intercept)
            totalLength++;
        double output[] = new double[totalLength];

        //Sum
        for (int i = 0; i < data1.length; i++)
            output[i] = data1[i] + data2[i];
        //Diff
        for (int i = data1.length; i < 2 * data1.length; i++)
            output[i] = Math.abs(data1[i - data1.length] - data2[i - data1.length]);
        //Cosine
        double norm1 = 0, norm2 = 0;
        for (int i = 0; i < data1.length; i++) {
            norm1 += data1[i] * data1[i];
            norm2 += data2[i] * data2[i];
        }
        norm1 = Math.sqrt(norm1); norm2 = Math.sqrt(norm2);
        for (int i = 0; i < data1.length; i++)
            output[2 * data1.length + i] = data1[i] * data2[i] / (norm1 * norm2);
        //Intercept?
        if (intercept)
            output[totalLength - 1] = 1.;

        return output;
    }

    public static double[] buildDiffCosine(double data1[], double data2[], boolean intercept) {
        int totalLength = 2 * data1.length;
        if (intercept)
            totalLength++;
        double output[] = new double[totalLength];

        //Diff
        for (int i = 0; i < data1.length; i++)
            output[i] = Math.abs(data1[i] - data2[i]);
        //Cosine
        double norm1 = 0, norm2 = 0;
        for (int i = 0; i < data1.length; i++) {
            norm1 += data1[i] * data1[i];
            norm2 += data2[i] * data2[i];
        }
        norm1 = Math.sqrt(norm1); norm2 = Math.sqrt(norm2);
        for (int i = 0; i < data1.length; i++)
            output[data1.length + i] = data1[i] * data2[i] / (norm1 * norm2);
        //Intercept?
        if (intercept)
            output[totalLength - 1] = 1.;

        return output;
    }

    public static int[] buildInteger(int data1[], int data2[], boolean intercept) {
        int totalLength = 2 * data1.length;
        if (intercept)
            totalLength++;
        int output[] = new int[totalLength];

        for (int i = 0; i < data1.length; i++)
            output[i] = (data1[i] + data2[i]) % 2;
        for (int i = 0; i < data1.length; i++)
            output[data1.length + i] = data1[i] * data2[i];

        if (intercept)
            output[totalLength - 1] = 1;

        return output;
    }

    public static double[] buildIntegerLike(double data1[], double data2[], boolean intercept) {
        int totalLength = 2 * data1.length;
        if (intercept)
            totalLength++;
        double output[] = new double[totalLength];

        for (int i = 0; i < data1.length; i++)
            output[i] = (((int) (data1[i] + data2[i]))) % 2;
        for (int i = 0; i < data1.length; i++)
            output[data1.length + i] = data1[i] * data2[i];

        if (intercept)
            output[totalLength - 1] = 1;

        return output;
    }

    public static int[] buildSparse(int data1[], int data2[], boolean intercept) {
        int buffer[] = new int[2 * data1.length + 1];
        int bufferPos = 0;

        for (int i = 0; i < data1.length; i++) 
            if (data1[i] != 0 || data2[i] != 0)
                buffer[bufferPos++] = i;
        for (int i = 0; i < data1.length; i++)
            if (data1[i] != 0 && data2[i] != 0)
                buffer[bufferPos++] = data1.length + i;

        if (intercept)
            buffer[bufferPos++] = 2 * data1.length;

        int output[] = new int[bufferPos];
        System.arraycopy(buffer, 0, output, 0, bufferPos);
        return output;
    }

    public static double[] buildConcat(double data1[], double data2[]) {
        int totalLength = 2 * data1.length;
        double output[] = new double[totalLength];

        for (int i = 0; i < data1.length; i++)
            output[i] = data1[i];
        for (int i = data1.length; i < 2 * data1.length; i++)
            output[i] = data2[i - data1.length];

        return output;
    }

    public static double[] buildConcat(int data1[], int data2[], int numFeatures) {
        int totalLength = 2 * numFeatures;
        double output[] = new double[totalLength];

        for (int i = 0; i < data1.length; i++)
            output[data1[i]] = 1.;
        for (int i = 0; i < data2.length; i++)
            output[numFeatures + data2[i]] = 1.;

        return output;
    }

}
