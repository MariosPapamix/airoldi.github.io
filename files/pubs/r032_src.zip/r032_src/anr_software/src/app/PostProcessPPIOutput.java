package analogy.app;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.List;
import java.util.ArrayList;

/**
 * This class generates summary statistics of the output
 * of a run of QueryPPI
 */

public class PostProcessPPIOutput {

    public static int NUM_ALGO = 4;
    public static int NUM_TRIALS = 5;

    public static String FILE_NAME = "new-kegg-hybrid-basic.log"; //Example

    public static void main(final String[] argv)
    {
        System.out.println("** Protein-protein interaction retrieval: summarize log file");
        System.out.println(" - Code by Ricardo Silva, University College London, 2009");
        System.out.println(" - First release: August 1st 2009");
        System.out.println(" - Last modification: August 1st 2009");
        System.out.println();

        if (argv.length != 1) {
            System.out.println("Usage: PostProcessPPIOutput <log filename>");
            System.exit(0);
        }

        FILE_NAME = argv[0];

        try {
            List<double[]> results = processLog(FILE_NAME);
            List<Double> coverage = processLogCoverage(FILE_NAME);

            System.out.println("Total #comparisons = " + results.size() / NUM_TRIALS + " (" + results.size() + ")");
            for (int i = 0; i < NUM_ALGO; i++) {
                int numVictories[] = countWins(i, results);
                System.out.println("Total wins [" + i + "]: " + numVictories[0] / NUM_TRIALS + "(AUC), " +
                                                                numVictories[1] / NUM_TRIALS + "(TopTen)");
            }
            System.out.println();
            for (int i = 0; i < NUM_ALGO; i++) {
                int numVictories[] = countSmoothedWins(i, results);
                System.out.println("Total smoothed wins [" + i + "]: " + numVictories[0] + "(AUC), " +
                                                                         numVictories[1] + "(TopTen)");
            }
            System.out.println();
            for (int i = 0; i < NUM_ALGO; i++) {
                int hist[] = top10Histogram(i, results);
                System.out.print("Top10 histogram [" + i + "]: ");
                for (int j = 0; j < hist.length; j++) {
                    double prop = ((int) (100 * hist[j] / ((double) results.size()))) / 100.;
                    System.out.print(prop + " ");
                }
                System.out.println();
            }
            System.out.println("\nGNU histogram data:\n");
            int allHist[][] = new int[NUM_ALGO][];
            for (int i = 0; i < NUM_ALGO; i++)
                allHist[i] = top10Histogram(i, results);
            System.out.println("hits COS NN RR BR");
            for (int j = 0; j < allHist[0].length; j++) {
                System.out.print(j + " ");
                for (int i = 0; i < NUM_ALGO; i++) {
                    //double prop = ((int) (100 * allHist[i][j] / ((double) results.size()))) / 100.;
                    double prop = (allHist[i][j] / (double) results.size());
                    System.out.print(prop + " ");
                }
                System.out.println();
            }
            System.out.println();
            System.out.println("Population coverage:");
            int numPerfect = 0, num95 = 0, num75 = 0;
            double histogram[] = new double[10];
            for (int i = 0; i < coverage.size(); i++) {
                int pos = (int) Math.floor(coverage.get(i) / 10);
                if (pos == 10)
                    pos--;
                histogram[pos]++;
                //System.out.println(coverage.get(i));
                if (coverage.get(i) == 100.)
                    numPerfect++;
                if (coverage.get(i) > 95.)
                    num95++;
                if (coverage.get(i) > 75.)
                    num75++;
            }
            for (int i = 0; i < histogram.length; i++)
                System.out.println((10 * (i + 1) + " " + histogram[i] / coverage.size()));
            System.out.println("NumPerfect = " + numPerfect / (double) coverage.size());
            System.out.println("Num95 = " + num95 / (double) coverage.size());
            System.out.println("Num75 = " + num75 / (double) coverage.size());
            System.out.println();
            double aucMatrix[][] = new double[NUM_ALGO][NUM_ALGO];
            double topTenMatrix[][] = new double[NUM_ALGO][NUM_ALGO];
            for (int i = 0; i < NUM_ALGO; i++)
                for (int j = i + 1; j < NUM_ALGO; j++) {
                    double pairwiseVictories[] = countPairwiseWins(i, j, results);
                    aucMatrix[i][j] = pairwiseVictories[0];
                    aucMatrix[j][i] = pairwiseVictories[1];
                    topTenMatrix[i][j] = pairwiseVictories[2];
                    topTenMatrix[j][i] = pairwiseVictories[3];
                }
            System.out.println("AUC comparisons");
            for (int i = 0; i < NUM_ALGO; i++) {
                for (int j = 0; j < NUM_ALGO; j++) {
                    //double rounded = ((int) (100 * aucMatrix[i][j] / results.size())) / 100.;
                    double rounded = ((int) (100 * aucMatrix[i][j])) / 100.;
                    System.out.print(rounded + " ");
                }
                System.out.println();
            }
            System.out.println();
            System.out.println("TopTen comparisons");
            for (int i = 0; i < NUM_ALGO; i++) {
                for (int j = 0; j < NUM_ALGO; j++) {
                    //double rounded = ((int) (100 * topTenMatrix[i][j] / results.size())) / 100.;
                    double rounded = ((int) (100 * topTenMatrix[i][j])) / 100.;
                    System.out.print(rounded + " ");
                }
                System.out.println();
            }

        } catch (java.io.IOException e) {
            System.out.println("File error: " + e.toString());
        }
        System.out.println();
        System.out.println("Done!");
    }


    public static List<double[]> processLog(String fileName) throws java.io.IOException
    {
        BufferedReader in = new BufferedReader(new FileReader(fileName));
        String line = in.readLine();

        List<double[]> results = new ArrayList<double[]>();

        readingAll:
        while (line != null) {
            do {
                line = in.readLine();
                if (line == null)
                    break readingAll;
            } while (!line.startsWith("*** Experiment #"));
            //System.out.println(">> READING " + line);
            List<double[]> exp = new ArrayList<double[]>();
            for (int t = 0; t < NUM_TRIALS; t++) {
                in.readLine(); in.readLine();
                double result[] = new double[NUM_ALGO * 2];
                for (int i = 0; i < NUM_ALGO; i++) {
                    line = in.readLine();
                    if (line.startsWith("Result *> TRIVIAL"))
                        continue readingAll;
                    String tokens[] = line.split(" +|,+|\\(+|\\)+");
                    double p1 = Double.parseDouble(tokens[9]), p2 = Double.parseDouble(tokens[13]);
                    if (p1 < 20 || p2 - p1 < 5) //too trivial
                        continue readingAll;
                    result[i * 2] = Double.parseDouble(tokens[3]);
                    result[i * 2 + 1] = Double.parseDouble(tokens[tokens.length - 1]);
                }
                in.readLine();
                exp.add(result);
            }
            results.addAll(exp); //Notice: it only adds all NUM_TRIALS results, or none
        }

        in.close();

        return results;
    }

    public static List<Double> processLogCoverage(String fileName) throws java.io.IOException
    {
        BufferedReader in = new BufferedReader(new FileReader(fileName));
        String line = in.readLine();

        List<Double> results = new ArrayList<Double>();

        readingAll:
        while (line != null) {
            do {
                line = in.readLine();
                if (line == null)
                    break readingAll;
            } while (!line.startsWith("*** Experiment #"));
            List<Double> exp = new ArrayList<Double>();
            for (int t = 0; t < NUM_TRIALS; t++) {
                in.readLine();
                line = in.readLine();
                String tokensP[] = line.split(" +|%|,+|\\(+|\\)+");
                double percentage = Double.parseDouble(tokensP[tokensP.length - 1]);
                for (int i = 0; i < NUM_ALGO; i++) {
                    line = in.readLine();
                    if (line.startsWith("Result *> TRIVIAL"))
                        continue readingAll;
                    String tokens[] = line.split(" +|,+|\\(+|\\)+");
                    double p1 = Double.parseDouble(tokens[9]), p2 = Double.parseDouble(tokens[13]);
                    if (p1 < 20 || p2 - p1 < 5) //too trivial
                        continue readingAll;
                }
                in.readLine();
                exp.add(percentage);
            }
            results.addAll(exp); //Notice: it only adds all NUM_TRIALS results, or none
        }

        in.close();

        return results;
    }

    public static int[] countWins(int algoPos, List<double[]> results)
    {
        int victories[] = new int[2];
        int numExp = results.size() / NUM_TRIALS;
        for (int i = 0; i < numExp; i++) {
            for (int j = 0; j < NUM_TRIALS; j++) {
                double result[] = results.get(i * NUM_TRIALS + j);
                double maxAUC = -Double.MAX_VALUE, maxTopTen = -Double.MAX_VALUE;
                for (int k = 0; k < NUM_ALGO; k++) {
                    if (result[2 * k] > maxAUC)
                        maxAUC = result[2 * k];
                    if (result[2 * k + 1] > maxTopTen)
                        maxTopTen = result[2 * k + 1];
                }
                if (result[2 * algoPos] == maxAUC)
                    victories[0]++;
                if (result[2 * algoPos + 1] == maxTopTen)
                    victories[1]++;
            }
        }
        return victories;
    }

    public static double[] countPairwiseWins(int algoPos1, int algoPos2, List<double[]> results)
    {
        double victories[] = new double[6];
        int numExp = results.size() / NUM_TRIALS;
        for (int i = 0; i < numExp; i++) {
            for (int j = 0; j < NUM_TRIALS; j++) {
                double result[] = results.get(i * NUM_TRIALS + j);
                double auc1 = result[2 * algoPos1], topTen1 = result[2 * algoPos1 + 1];
                double auc2 = result[2 * algoPos2], topTen2 = result[2 * algoPos2 + 1];
                if (auc1 > auc2)
                    victories[0]++;
                if (auc1 < auc2)
                    victories[1]++;
                if (auc1 == auc2)
                    victories[4]++;
                if (topTen1 > topTen2)
                    victories[2]++;
                if (topTen1 < topTen2)
                    victories[3]++;
                if (topTen1 == topTen2)
                    victories[5]++;

            }
        }
        victories[0] /= (results.size() - victories[4]);
        victories[1] /= (results.size() - victories[4]);
        victories[2] /= (results.size() - victories[5]);
        victories[3] /= (results.size() - victories[5]);
        return victories;
    }

    /**
     * Only count wins if it wins most of the time for each sequence of NUM_TRIALS
     */

    public static int[] countSmoothedWins(int algoPos, List<double[]> results)
    {
        int victories[] = new int[2];
        int numExp = results.size() / NUM_TRIALS;
        int threshold = (int) Math.ceil(0.5 * NUM_TRIALS);
        for (int i = 0; i < numExp; i++) {
            int partialWinsAUC = 0, partialWinsTopTen = 0;
            for (int j = 0; j < NUM_TRIALS; j++) {
                double result[] = results.get(i * NUM_TRIALS + j);
                double maxAUC = -Double.MAX_VALUE, maxTopTen = -Double.MAX_VALUE;
                for (int k = 0; k < NUM_ALGO; k++) {
                    if (result[2 * k] > maxAUC)
                        maxAUC = result[2 * k];
                    if (result[2 * k + 1] > maxTopTen)
                        maxTopTen = result[2 * k + 1];
                }
                if (result[2 * algoPos] == maxAUC)
                    partialWinsAUC++;
                if (result[2 * algoPos + 1] == maxTopTen)
                    partialWinsTopTen++;
            }
            if (partialWinsAUC >= threshold)
                victories[0]++;
            if (partialWinsTopTen >= threshold)
                victories[1]++;
        }
        return victories;
    }

    /**
     * Returns a histogram indicating how many 0s, 1s, 2s, ..., 10s were obtained
     * in the top 10.
     */

    public static int[] top10Histogram(int algoPos, List<double[]> results)
    {
        int hits[] = new int[11];
        int numExp = results.size() / NUM_TRIALS;
        for (int i = 0; i < numExp; i++) {
            for (int j = 0; j < NUM_TRIALS; j++) {
                double result[] = results.get(i * NUM_TRIALS + j);
                hits[(int) result[2 * algoPos + 1]]++;
            }
        }
        return hits;
    }
}
