package analogy.app;

import analogy.prediction.Logistic;

import java.util.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.PrintWriter;

/**
 * This class merges and processes two datasets:
 *
 * - 'Qi', the dataset used in the following article
 *
 *      Y. Qi, Z. Bar-Joseph, and J. Klein-Seetharaman. Evaluation of different biological data
 *        and computational classification methods for use in protein interaction prediction.
 *        Proteins, 63:490�500, 2006
 *
 * - 'Edo', the dataset we construct by joining several other sources.
 *
 * To obtain the 'Qi' dataset, please refer to the journal webpage. We assume 'Qi' files are all in a directory called
 * 'qi' that is in the path, and that 'Edo' files are in a directory called 'edo'.
 *
 * You need two arguments: the first is the seed for the random number generator, while the second is the name of the
 * dataset (MIPS or KEGG features). In the experiments for the AOAS paper, we used the seed 19580427.
 *
 * Command line example (classes were stored in the ``..\classes'' directory):
 *
 * > java -cp .;weka.jar;colt.jar;..\classes -mx1200m analogy.app.ProcessProteinMicroarray 19580427 MIPS
 *
 * At the end, you will have generated 8 files.
 *
 *  - protein.ids.dat: an index of all proteins. Needed for queries.
 *  - positiveMicroarray.dat: all positive (linked) pairs. Needed for queries.
 *  - negativeMicroarray.dat: all negative (not-linked) pairs. Not needed. Since it is a large file, feel free to delete it.
 *  - negsmallMicroarray.dat: a subsample of negativeMicroarray, needed for the non-Bayesian logistic approach.
 *  - positiveEdo/negativeEdo.dat: auxiliary files. Can be deleted.
 *  - prior.microarray.pair/prior.microarray.pair.cov: priors for the RelationalBayesianSets. Also required. 
 */

public class ProcessProteinMicroarray {

    private static int    NUM_POS_PAIR;
    private static int    NUM_NEG_PAIR;
    private static int    NUM_NEG_PAIR_SMALL;
    private static String POS_PAIR;
    private static String POS_PAIR_FEATURE;
    private static String POS_PAIR_FEATURE_SEL;
    private static String NEG_PAIR;
    private static String NEG_PAIR_FEATURE;
    private static String NEG_PAIR_FEATURE_SEL;

    private static int NUM_VARS_QI   = 20;
    private static int NUM_VARS_EDO  = 25;
    private static boolean SMALL_NEG = false;

    private static String POSITIVE_FILENAME = "positiveMicroarray.dat";
    private static String NEGATIVE_FILENAME = "negativeMicroarray.dat";
    private static String NEGSMALL_FILENAME = "negSmallMicroarray.dat";

    /**
     * Main:
     *
     * In the experiments for the AOAS paper, we used the seed 19580427.
     *
     * If you run out of memory, first make sure you expand it by using some virtual machine command
     * such as '-mx1000m'.
     */

    public static void main(final String[] argv)
    {
        if (argv.length != 2) {
            System.out.println("Usage: ProcessProteinMicroarray <seed> <dataset>, where " +
                               "dataset = MIPS or KEGG");
            System.exit(0);
        }

        setConstants(argv[1]);

        System.out.println("Processing positive instances...");
        preProcessIdFeature(POS_PAIR, POS_PAIR_FEATURE, NUM_POS_PAIR);
        System.out.println("Processing negative instances...");
        preProcessIdFeature(NEG_PAIR, NEG_PAIR_FEATURE, NUM_NEG_PAIR);
        Hashtable<String, double[][]> edoData = getEdoData("ppi/edo/microarray");
        generateEdoFeatureFiles(edoData, POS_PAIR, NEG_PAIR);
        generateQiEdoProcessedFeatureFiles(POS_PAIR_FEATURE_SEL, NEG_PAIR_FEATURE_SEL);
        edoData.clear();

        subsample(NEGATIVE_FILENAME, NEGSMALL_FILENAME, NUM_NEG_PAIR_SMALL, Integer.valueOf(argv[0]));


        buildPriorMean();
        buildPriorCov();
        System.out.println("Done!");
    }

    protected static void setConstants(String dataId) {
        if (dataId.equals("MIPS")) {
            NUM_POS_PAIR = 8236;
            NUM_NEG_PAIR = 236786;
            NUM_NEG_PAIR_SMALL = 10000;
            POS_PAIR = "ppi/qi/mipsPosPair";
            POS_PAIR_FEATURE = "ppi/qi/mipsPosPair.feature";
            POS_PAIR_FEATURE_SEL = "ppi/qi/mipsPosPair.feature.sel";
            NEG_PAIR = "ppi/qi/mipsRandpairSub23w";
            NEG_PAIR_FEATURE = "ppi/qi/mipsRandpairSub23w.feature";
            NEG_PAIR_FEATURE_SEL = "ppi/qi/mipsRandpairSub23w.feature.sel";
            return;
        }
        if (dataId.equals("KEGG")) {
            NUM_POS_PAIR = 38961;
            NUM_NEG_PAIR = 237215;
            NUM_NEG_PAIR_SMALL = 10000;
            POS_PAIR = "ppi/qi/keggscie04PosPair";
            POS_PAIR_FEATURE = "ppi/qi/keggscie04PosPair.feature";
            POS_PAIR_FEATURE_SEL = "ppi/qi/keggscie04PosPair.feature.sel";
            NEG_PAIR = "ppi/qi/keggscie04RandpairSub23w";
            NEG_PAIR_FEATURE = "ppi/qi/keggscie04RandpairSub23w.feature";
            NEG_PAIR_FEATURE_SEL = "ppi/qi/keggscie04RandpairSub23w.feature.sel";
            return;
        }
        throw new RuntimeException("Dataset not recognized: use MIPS or KEGG");
    }

    /*******************************************************************************************************************
     * Process Qi's data.
     *
     * Selects the gene expression features and throw away rows with missing data
     * (as indicated by the string "-100").
     */

    protected static void preProcessIdFeature(String idsFileName, String featuresFileName, int size) {
        try {
            BufferedReader ids = new BufferedReader(new FileReader(idsFileName));
            BufferedReader features = new BufferedReader(new FileReader(featuresFileName));
            PrintWriter    idsOut = new PrintWriter(idsFileName + ".sel");
            PrintWriter    featuresOut = new PrintWriter(featuresFileName + ".sel");
            HashSet<String> singleIds = new HashSet<String>();

            int numAccepted = 0;

            nextPair:
            for (int i = 0; i < size; i++) {
                String lineId = ids.readLine().trim();
                String lineFeatures = features.readLine().trim();
                String featuresStr[] = lineFeatures.split(",");
                String idsStr[] = lineId.split(" |\t+");

                int numMissing = 0;
                for (int j = 0; j < 20; j++)
                    if (featuresStr[j].equals("-100"))
                        numMissing++;
                if (numMissing > 10)
                    continue nextPair;
                idsOut.println(lineId);
                for (int j = 0; j < 20; j++)
                    featuresOut.print(featuresStr[j] + " ");
                featuresOut.println();
                numAccepted++;

                for (int j = 0; j < 2; j++)
                    if (!singleIds.contains(idsStr[j]))
                        singleIds.add(idsStr[j]);
            }

            idsOut.close(); featuresOut.close(); ids.close(); features.close();

            PrintWriter singleIdsOut = new PrintWriter("protein.ids.dat");
            for (String id : singleIds)
                singleIdsOut.println(id);
            singleIdsOut.close();

            System.out.println("#Accepted = " + numAccepted);
        } catch (java.io.IOException e) {
            System.out.println("FILE ERROR. Quitting now...");
            throw new RuntimeException(e);
        }
    }

    /*******************************************************************************************************************
     * Build the empirical prior.
     */

    protected static void buildPriorMean() {
        try  {
            int numVars = (NUM_VARS_QI + NUM_VARS_EDO) + 1;

            int lineCountPos = 0, lineCountNeg = 0;
            for (int f = 0; f < 2; f++) {
                BufferedReader in;
                if (f == 0)
                    in = new BufferedReader(new FileReader(POSITIVE_FILENAME));
                else if (SMALL_NEG)
                    in = new BufferedReader(new FileReader(NEGSMALL_FILENAME));
                else
                    in = new BufferedReader(new FileReader(NEGATIVE_FILENAME));

                String line = null;
                int lineCount = 0;
                while (true) {
                    line = in.readLine();
                    if (line == null)
                        break;
                    line = line.trim();
                    if (line.equals(""))
                        continue;
                    lineCount++;
                }
                if (f == 0)
                    lineCountPos = lineCount;
                else
                    lineCountNeg = lineCount;
                in.close();
            }

            double data[][] = new double[lineCountPos + lineCountNeg][numVars - 1];
            int    lineCount = 0;

            for (int f = 0; f < 2; f++) {
                BufferedReader in;
                if (f == 0)
                    in = new BufferedReader(new FileReader(POSITIVE_FILENAME));
                else if (SMALL_NEG)
                    in = new BufferedReader(new FileReader(NEGSMALL_FILENAME));
                else
                    in = new BufferedReader(new FileReader(NEGATIVE_FILENAME));

                String line = null;

                while (true) {
                    System.out.println("Reading line " + lineCount);
                    line = in.readLine();
                    if (line == null)
                        break;
                    line = line.trim();
                    if (line.equals(""))
                        continue;
                    String tokens[] = line.split(" +|\t+");
                    for (int i = 0; i < numVars - 1; i++)
                        //Exclude the last variable, which is a constant (Weka has a default intercept term, so no need for this)
                        data[lineCount][i] = Double.valueOf(tokens[i]);
                    lineCount++;
                }

                in.close();
            }

            int classes[] = new int[lineCountPos + lineCountNeg];
            for (int i = 0; i < lineCountPos; i++)
                classes[i] = 1;
            for (int i = lineCountPos; i < lineCountPos + lineCountNeg; i++)
                classes[i] = 0;

            Logistic logistic = new Logistic(data, classes, false);
            System.out.println("Fitting empirical prior...");
            logistic.train();
            double coeff[] = logistic.getParams();
            for (int i = 0; i < coeff.length; i++)
                coeff[i] = -coeff[i]; //Since Weka's default is to treat class 0 as the positive class

            System.out.println("Saving coefficients...");
            PrintWriter out = new PrintWriter("prior.microarray.pair");
            for (int i = 1; i < numVars; i++) {
                out.println(coeff[i]);
                System.out.println(coeff[i]);
            }
            out.println(coeff[0]); System.out.println(coeff[0]); //Intercept should be the last one
            out.close();

        } catch (java.io.IOException e) {
            System.out.println("FILE ERROR. Quitting now...");
        }
    }

    protected static void buildPriorCov() {
        try  {
            int numVars = (NUM_VARS_QI + NUM_VARS_EDO) + 1;
            double cov[][] = new double[numVars][numVars];

            BufferedReader in = new BufferedReader(new FileReader(POSITIVE_FILENAME));
            String line = null;
            int lineCount = 0;

            while (true) {
                System.out.println("Reading line " + lineCount);
                line = in.readLine();
                if (line == null)
                    break;
                line = line.trim();
                if (line.equals(""))
                    continue;
                lineCount++;
                String tokens[] = line.split(" +|\t+");
                double row[] = new double[tokens.length];
                for (int i = 0; i < numVars; i++)
                    row[i] = Double.valueOf(tokens[i]);
                for (int i = 0; i < numVars; i++)
                    for (int j = 0; j < numVars; j++)
                        cov[i][j] += row[i] * row[j];
            }

            PrintWriter out = new PrintWriter("prior.microarray.pair.cov");
            for (int i = 0; i < numVars; i++) {
                for (int j = 0; j < numVars; j++)
                    out.print(cov[i][j] / lineCount + " ");
                out.println();
            }
            out.close();

        } catch (java.io.IOException e) {
            System.out.println("FILE ERROR. Quitting now...");
        }
    }

    private static double[] buildDataPoint(double original[]) {
        double output[] = new double[original.length];
        double norm = 0;
        for (int i = 0; i < original.length; i++)
            norm += original[i] * original[i];
        norm = Math.sqrt(norm);
        for (int i = 0; i < original.length; i++)
            output[i] = original[i] / norm;
        return output;
    }

    /*******************************************************************************************************************
     * Choose the subsample of negative points used by the
     * @param inputFileName
     * @param outputFileName
     * @param numSamples
     * @param seed
     */
    protected static void subsample(String inputFileName, String outputFileName, int numSamples, int seed)
    {
        Random r = new Random(seed);
        try {
            int inputSize = 0;
            BufferedReader in = new BufferedReader(new FileReader(inputFileName));
            while (in.readLine() != null) inputSize++;
            in.close();

            int inputChoice[] = new int[inputSize];
            for (int i = 0; i < inputSize; i++)
                 inputChoice[i] = 0;
            for (int i = 0; i < numSamples; i++)
                 inputChoice[r.nextInt(inputSize)]++;

            in = new BufferedReader(new FileReader(inputFileName));
            PrintWriter out = new PrintWriter(outputFileName);

            for (int i = 0; i < inputSize; i++) {
                System.out.println("Reading line " + i);
                String line = in.readLine();
                for (int j = 0; j < inputChoice[i]; j++)
                    out.println(line);
            }
            in.close(); out.close();
        } catch (java.io.IOException e) {
            System.out.println("FILE ERROR. Quitting now...");
            throw new RuntimeException(e);
        }
    }

    /*******************************************************************************************************************
     * Combine Qi's data with Edo's data
     */

    protected static Hashtable<String, double[][]> getEdoData(String directory)
    {
        String fileNames[] = {
            "Brem05_dyeSwap.flt.knn.avg.pcl"                  ,
            "Brem05_orig.flt.knn.avg.pcl"                     ,
            "Gasch00_adenineStarvation.flt.knn.avg.pcl"       ,
            "Gasch00_carbonSources.flt.knn.avg.pcl"           ,
            "Gasch00_diamideTreatment.flt.knn.avg.pcl"        ,
            "Gasch00_DTT(y13).flt.knn.avg.pcl"                ,
            "Gasch00_DTT(y14).flt.knn.avg.pcl"                ,
            "Gasch00_HOtimeCourse.flt.knn.avg.pcl"            ,
            "Gasch00_HS25-37.flt.knn.avg.pcl"                 ,
            "Gasch00_HS29-33.flt.knn.avg.pcl"                 ,
            "Gasch00_HS30-37.flt.knn.avg.pcl"                 ,
            "Gasch00_HS37-25.flt.knn.avg.pcl"                 ,
            "Gasch00_HSmild.flt.knn.avg.pcl"                  ,
            "Gasch00_HSto37.flt.knn.avg.pcl"                  ,
            "Gasch00_hyper-osmotic.flt.knn.avg.pcl"           ,
            "Gasch00_hypo-osmotic.flt.knn.avg.pcl"            ,
            "Gasch00_menadione.flt.knn.avg.pcl"               ,
            "Gasch00_Ndepletion.flt.knn.avg.pcl"              ,
            "Gasch00_stationaryPhase(y12).flt.knn.avg.pcl"    ,
            "Gasch00_stationaryPhase(y14).flt.knn.avg.pcl"    ,
            "Gasch00_steadyState(y13).flt.knn.avg.pcl"        ,
            "Gasch00_steadyState(y14).flt.knn.avg.pcl"        ,
            "Primig00.filter.flt.knn.avg.log.pcl"             ,
            "Yvert03_dyeSwap.flt.knn.avg.pcl"                 ,
            "Yvert03_orig.flt.knn.avg.pcl"
        };
        for (int i = 0; i < fileNames.length; i++)
            fileNames[i] = directory + "/" + fileNames[i];
        Hashtable<String, double[][]> output = new Hashtable<String, double[][]>();
        try {
            for (int i = 0; i < fileNames.length; i++) {
                System.out.println("Reading " + fileNames[i]);
                BufferedReader in = new BufferedReader(new FileReader(fileNames[i]));
                in.readLine(); in.readLine();
                String line = in.readLine();
                do {
                    String tokens[] = line.split("\\t| +");
                    String id = tokens[0];
                    double values[] = new double[tokens.length - 3];
                    for (int j = 0; j < values.length; j++)
                         values[j] = Double.parseDouble(tokens[2 + j]);
                    if (!output.containsKey(id))
                        output.put(id, new double[fileNames.length][]);
                    output.get(id)[i] = values;
                    line = in.readLine();
                } while (line != null);
                in.close();
            }
        } catch (java.io.IOException e) {
            System.out.println("FILE ERROR. Quitting now...");
        }
        return output;
    }

    protected static void generateEdoFeatureFiles(Hashtable<String, double[][]> edoData,
                                                  String posIdsFileName, String negIdsFileName)
    {
        int numEdoNull = 0;

        try {
            BufferedReader inputIds;
            PrintWriter    featuresOut;

            for (int i = 0; i < 2; i++) {

                if (i == 0) {
                    inputIds = new BufferedReader(new FileReader(posIdsFileName + ".sel"));
                    featuresOut = new PrintWriter("positiveEdo.dat");
                }
                else {
                    inputIds = new BufferedReader(new FileReader(negIdsFileName + ".sel"));
                    featuresOut = new PrintWriter("negativeEdo.dat");
                }
                while (true) {
                    String lineIds = inputIds.readLine();
                    if (lineIds == null)
                        break;
                    String ids[] = lineIds.split("\t| +");

                    double newPoint[] = new double[NUM_VARS_EDO];

                    double edoFeatures1[][] = edoData.get(ids[0]);
                    double edoFeatures2[][] = edoData.get(ids[1]);
                    if (edoFeatures1 == null || edoFeatures2 == null) {
                        numEdoNull++;
                        for (int j = 0; j < NUM_VARS_EDO; j++)
                            newPoint[j] = -100;
                    } else {
                        for (int j = 0; j < NUM_VARS_EDO; j++) {
                            if (edoFeatures1[j] == null || edoFeatures2[j] == null) {
                                newPoint[j] = -100;
                                continue;
                            }

                            int numFeatures = edoFeatures1[j].length;
                            double sum1 = 0, sum2 = 0, sum_sq1 = 0, sum_sq2 = 0, sum_12 = 0;
                            for (int k = 0; k < numFeatures; k++) {
                                sum1 += edoFeatures1[j][k];
                                sum2 += edoFeatures2[j][k];
                                sum_sq1 += edoFeatures1[j][k] * edoFeatures1[j][k];
                                sum_sq2 += edoFeatures2[j][k] * edoFeatures2[j][k];
                                sum_12 += edoFeatures1[j][k] * edoFeatures2[j][k];
                            }
                            double mean1 = sum1 / numFeatures, mean2 = sum2 / numFeatures;
                            double cov  =  sum_12 / numFeatures  - mean1 * mean2,
                                   var1 = sum_sq1 / numFeatures - mean1 * mean1,
                                   var2 = sum_sq2 / numFeatures - mean2 * mean2;
                            double corr = cov / Math.sqrt(var1 * var2);
                            newPoint[j] = corr;
                        }
                    }
                    for (int j = 0; j < NUM_VARS_EDO; j++)
                        featuresOut.print(newPoint[j] + " ");
                    featuresOut.println();
                }
                featuresOut.close(); inputIds.close();
            }

        } catch (java.io.IOException e) {
            System.out.println("FILE ERROR. Quitting now...");
            throw new RuntimeException(e);
        }
        System.out.println("NumEdoNull = " + numEdoNull);
    }

    protected static void generateQiEdoProcessedFeatureFiles(String posFeaturesFileName, String negFeaturesFileName)
    {
        try {
            double meanPos[] = new double[NUM_VARS_QI + NUM_VARS_EDO], meanNeg[] = new double[NUM_VARS_QI + NUM_VARS_EDO];
            int    countPos[] = new int[NUM_VARS_QI + NUM_VARS_EDO], countNeg[] = new int[NUM_VARS_QI + NUM_VARS_EDO];

            System.out.println("Calculating means...");
            for (int i = 0; i < 2; i++) {
                double newPoint[] = new double[NUM_VARS_QI + NUM_VARS_EDO];
                BufferedReader input, inputEdo;
                if (i == 0) {
                    input = new BufferedReader(new FileReader(posFeaturesFileName));
                    inputEdo = new BufferedReader(new FileReader("positiveEdo.dat"));
                }
                else {
                    input = new BufferedReader(new FileReader(negFeaturesFileName));;
                    inputEdo = new BufferedReader(new FileReader("negativeEdo.dat"));
                }
                while (true) {
                    String line = input.readLine();
                    if (line == null || line.trim().length() == 0)
                        break;
                    String lineEdo = inputEdo.readLine();
                    String features[] = line.split(" +");
                    String featuresEdo[] = lineEdo.split(" +");
                    for (int j = 0; j < NUM_VARS_QI; j++) {
                        newPoint[j] = Double.parseDouble(features[j]);
                        if (i == 0 && !features[j].equals("-100")) {
                            meanPos[j] += newPoint[j];
                            countPos[j]++;
                        } else if (i == 1 && !features[j].equals("-100")) {
                            meanNeg[j] += newPoint[j];
                            countNeg[j]++;
                        }
                    }
                    for (int j = 0; j < NUM_VARS_EDO; j++) {
                        newPoint[NUM_VARS_QI + j] = Double.parseDouble(featuresEdo[j]);
                        if (i == 0 && !featuresEdo[j].startsWith("-100")) {
                            meanPos[NUM_VARS_QI + j] += newPoint[NUM_VARS_QI + j];
                            countPos[NUM_VARS_QI + j]++;
                        } else if (i == 1 && !featuresEdo[j].startsWith("-100")) {
                            meanNeg[NUM_VARS_QI + j] += newPoint[NUM_VARS_QI + j];
                            countNeg[NUM_VARS_QI + j]++;
                        }
                    }
                }
                input.close(); inputEdo.close();
            }

            for (int j = 0; j < NUM_VARS_QI + NUM_VARS_EDO; j++) {
                meanPos[j] /= countPos[j];
                meanNeg[j] /= countNeg[j];
                System.out.println("means[" + j + "] = {" + meanPos[j] + ", " + meanNeg[j] + "}");
            }

            PrintWriter    posFeaturesOut = new PrintWriter(POSITIVE_FILENAME);
            PrintWriter    negFeaturesOut = new PrintWriter(NEGATIVE_FILENAME);

            System.out.println("Generating files...");
            for (int i = 0; i < 2; i++) {
                double newPoint[] = new double[NUM_VARS_QI + NUM_VARS_EDO];
                BufferedReader input, inputEdo;
                PrintWriter output;
                if (i == 0) {
                    input = new BufferedReader(new FileReader(posFeaturesFileName));
                    inputEdo = new BufferedReader(new FileReader("positiveEdo.dat"));
                    output = posFeaturesOut;
                }
                else {
                    input = new BufferedReader(new FileReader(negFeaturesFileName));
                    inputEdo = new BufferedReader(new FileReader("negativeEdo.dat"));
                    output = negFeaturesOut;
                }
                int totalNull[] = new int[NUM_VARS_QI + NUM_VARS_EDO];
                while (true) {
                    String line = input.readLine();
                    if (line == null || line.trim().length() == 0)
                        break;
                    String lineEdo = inputEdo.readLine();
                    String features[] = line.split(" +");
                    String featuresEdo[] = lineEdo.split(" +");

                    for (int j = 0; j < NUM_VARS_QI; j++) {
                        newPoint[j] = Double.parseDouble(features[j]);
                        if (i == 0 && features[j].equals("-100"))
                            newPoint[j] = meanPos[j];
                        else if (i == 1 && features[j].equals("-100"))
                            newPoint[j] = meanNeg[j];
                        if (features[j].equals("-100"))
                            totalNull[j]++;
                    }
                    for (int j = 0; j < NUM_VARS_EDO; j++) {
                        newPoint[NUM_VARS_QI + j] = Double.parseDouble(featuresEdo[j]);
                        if (i == 0 && featuresEdo[j].startsWith("-100"))
                            newPoint[NUM_VARS_QI + j] = meanPos[NUM_VARS_QI + j];
                        else if (i == 1 && featuresEdo[j].startsWith("-100"))
                            newPoint[NUM_VARS_QI + j] = meanNeg[NUM_VARS_QI + j];
                        if (featuresEdo[j].startsWith("-100"))
                            totalNull[NUM_VARS_QI + j]++;
                    }
                    double datapoint[] = buildDataPoint(newPoint);
                    for (int j = 0; j < datapoint.length; j++)
                        output.print(datapoint[j] + " ");
                    output.println("1");
                }
                input.close(); inputEdo.close();
                String type;
                if (i == 0)
                    type = "+";
                else
                    type = "-";
                for (int j = 0; j < NUM_VARS_QI + NUM_VARS_EDO; j++)
                    System.out.println(type + "numNull[" + j + "] = " + totalNull[j]);
            }

            posFeaturesOut.close(); negFeaturesOut.close();

        } catch (java.io.IOException e) {
            System.out.println("FILE ERROR. Quitting now...");
            throw new RuntimeException(e);
        }
    }

}
