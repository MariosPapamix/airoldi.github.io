package analogy.app;

import analogy.bsets.*;

import java.util.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.PrintWriter;

/**
 * QueryWebKB: The analogical reasoning ranking system for webpage interactions.
 *
 * In order to use it, you will also need a 'webkb' directory storing all the data and gold standard information.
 *
 * You need one argument: the seed for the random number generator. In the experiments for the AOAS paper,
 * we used the seed 19580427.
 *
 * You will also have to have generated the processed data files and prior file. See 'ProcessWebKB' first.
 *
 * Command line example (classes were stored in the ``..\classes'' directory):
 *
 * > java -cp .;weka.jar;colt.jar;..\classes -mx800m analogy.app.QueryWebKB 19580427
 */


/**
 * The actual WebKB benchmark. Reads vocabulary, links and then output
 */

public class QueryWebKB extends ProcessWebKB {

    protected static String marginalDataBaseName = "webkb.data";
    protected static String indexName = "webkb-index-original.idx";
    protected static double c = 10008;
    protected static String METHOD = null;
    protected static String TASK   = null;
    protected static String UNI    = null;

    public static void main(final String[] argv) {
        System.out.println("WebKB");

        if (argv.length != 4) {
            System.out.println("Usage: QueryWebKB <seed> <method> <task> <university>, where " +
                                       "<method> = RBSETS, BSETS1, BSETS2, COS1 or COS2 and" +
                                       "<task> = SC (student -> course) or FP (faculty -> project) and " +
                                       "<university> = CORNELL or TEXAS or WASHINGTON or WISCONSIN");
            System.exit(0);
        }

        try {
            //if (args.length > 3 && args[2].equals("-pr")) {
            //    double area = calculateArea(QueryWebKB.DIR + args[3]);
            //    System.out.println("area = " + area);
            //    return;
            //}
            setConstants(argv[1], argv[2], argv[3]);

            List<String> fileNames = QueryWebKB.getFileNames();
            double svdData[][] = loadSVDData();
            String vocabArray[] = loadVocabulary();
            int    bernoulliData[][] = loadBernoulliData();
            int    links[][] = loadLinksArray(svdData.length);
            retrievalTest(svdData, links, bernoulliData, vocabArray.length, fileNames);
        } catch (java.io.IOException e) {
            System.out.println("ERROR WRITING FILE");
            System.out.println(e.getMessage());
        }
    }

    protected static void setConstants(String method, String task, String university) {
        method = method.toUpperCase(); task = task.toUpperCase(); university = university.toUpperCase();
        if (!method.equals("RBSETS") && !method.equals("BSETS1") && !method.equals("BSETS2")
             && !method.equals("COS1") && !method.equals("COS2"))
            throw new RuntimeException("Unknown method: " + method);
        if (!task.equals("SC") && !task.equals("FP"))
            throw new RuntimeException("Unknown task: " + task);
        if (!university.equals("CORNELL") && !university.equals("TEXAS") && !university.equals("WASHINGTON")
             && !university.equals("WISCONSIN"))
            throw new RuntimeException("Unknown university: " + university);
        METHOD = method; TASK = task; UNI = university;
    }

    protected static int[][] loadBernoulliData() {
        String fileName = QueryWebKB.DIR + QueryWebKB.marginalDataBaseName;
        int dataArray[][] = null;
        List docList = new ArrayList();
        try {
            BufferedReader file = new BufferedReader(new FileReader(fileName));
            String line = file.readLine();
            while (line != null && !line.equals("")) {
                String doc[] = line.split("\t");
                int docInt[] = new int[doc.length];
                for (int i = 0; i < doc.length; i++)
                    docInt[i] = Integer.valueOf(doc[i]).intValue();
                docList.add(docInt);
                line = file.readLine();
            }
            dataArray = new int[docList.size()][];
            for (int i = 0; i < dataArray.length; i++)
                dataArray[i] = (int[]) docList.get(i);
        } catch(java.io.FileNotFoundException e) {
            System.out.println("Warning! File not found: " + fileName);
            System.exit(0);
        } catch(java.io.IOException e) {
            System.out.println("Warning! IOException: " + fileName);
            System.exit(0);
        }
        return dataArray;
    }

    protected static String[] loadVocabulary() {
        String vocabArray[] = null;
        String fileName = QueryWebKB.DIR + QueryWebKB.vocabularyName;
        List vocabList = new ArrayList();
        try {
            BufferedReader file = new BufferedReader(new FileReader(fileName));
            String word = file.readLine();
            while (word != null && !word.equals("")) {
                vocabList.add(word);
                word = file.readLine();
            }
            vocabArray = new String[vocabList.size()];
            int count = 0;
            for (Iterator it = vocabList.iterator(); it.hasNext();)
                vocabArray[count++] = (String) it.next();
        } catch(java.io.FileNotFoundException e) {
            System.out.println("Warning! File not found: " + fileName);
            System.exit(0);
        } catch(java.io.IOException e) {
            System.out.println("Warning! IOException: " + fileName);
            System.exit(0);
        }
        return vocabArray;
    }

    protected static List<String> getFileNames() {
        List<String> fileNames = new ArrayList<String>();
        String indexFileName = QueryWebKB.DIR + QueryWebKB.indexName;
        try {
            BufferedReader index = new BufferedReader(new FileReader(indexFileName));
            do {
                String  subDirectoryName = index.readLine();
                String  directoryName = subDirectoryName.substring(1, subDirectoryName.length() - 1) + "/";
                String  documentName = index.readLine();
                while (documentName != null && !documentName.equals("")) {
                    fileNames.add(directoryName + documentName);
                    documentName = index.readLine();
                }
                if (documentName == null)
                    break;
            } while (true);
        } catch(java.io.FileNotFoundException e) {
            System.out.println("Warning! File not found: " + indexFileName);
            System.exit(0);
        } catch(java.io.IOException e) {
            System.out.println("Warning! IOException: " + indexFileName);
            System.exit(0);
        }
        return fileNames;
    }

    public static int[][] loadClasses(Hashtable classCodes,  Hashtable uCodes) {
        String fileName = QueryWebKB.DIR + QueryWebKB.filesName;
        List classList = new ArrayList();
        List uList = new ArrayList();
        int numClasses = 0, numU = 0;
        try {
            BufferedReader file = new BufferedReader(new FileReader(fileName));
            String line = file.readLine();
            while (line != null && !line.equals("")) {
                String doc[] = line.split("/");
                int pos = 0;
                while (!doc[pos].equals("webkb"))
                   pos++;
                pos++;
                Object classCode = classCodes.get(doc[pos]);
                if (classCode == null) {
                    classCode = new Integer(numClasses++);
                    classCodes.put(doc[pos], classCode);
                    System.out.println("Adding new class: " + doc[pos]);
                }
                classList.add(classCode);
                pos++;
                Object uCode = uCodes.get(doc[pos]);
                if (uCode == null) {
                    uCode = new Integer(numU++);
                    uCodes.put(doc[pos], uCode);
                    System.out.println("Adding new university: " + doc[pos]);
                }
                uList.add(uCode);
                line = file.readLine();
            }
        } catch(java.io.FileNotFoundException e) {
            System.out.println("Warning! File not found: " + fileName);
            System.exit(0);
        } catch(java.io.IOException e) {
            System.out.println("Warning! IOException: " + fileName);
            System.exit(0);
        }
        int output[][] = new int[classList.size()][2];
        int countC = 0;
        for (Iterator it = classList.iterator(); it.hasNext();)
            output[countC++][0] = ((Integer) it.next()).intValue();
        int countU = 0;
        for (Iterator it = uList.iterator(); it.hasNext();)
            output[countU++][1] = ((Integer) it.next()).intValue();
        return output;
    }

    public static int[][] filterClass(int dataArray[][], int classes[][], int classKey, int uKey) {
        List filteredData = new ArrayList();
        for (int i = 0; i < dataArray.length; i++) {
            if (classes[i][0] == classKey && classes[i][1] == uKey)
                filteredData.add(dataArray[i]);
        }
        int output[][] = new int[filteredData.size()][];
        int count = 0;
        for (Iterator it = filteredData.iterator(); it.hasNext();)
            output[count++] = (int[]) it.next();
        return output;
    }

    public static void filterClassWithIds(double dataArray[][], int classes[][], int classKey, int uKey,
                                          List filteredData, List filteredIds) {
        filteredData.clear(); filteredIds.clear();
        for (int i = 0; i < dataArray.length; i++) {
            if (classes[i][0] == classKey && classes[i][1] == uKey) {
                filteredIds.add(new Integer(i));
                filteredData.add(dataArray[i]);
            }
        }
    }

    protected static void retrievalTest(double svdData[][], int links[][], int bernoulliData[][],
                                        int numVarsBernoulli, List<String> fileNames)
                                        throws java.io.IOException
    {

        Random r = new Random();
        String classTarget1 = null, classTarget2 = null;

        if (TASK.equals("SC")) {
            classTarget1 = "student";
            classTarget2 = "course";
        } else {
            classTarget1 = "faculty";
            classTarget2 = "project";
        }
        List<String> trainUni = new ArrayList<String>();
        trainUni.add("texas"); trainUni.add("wisconsin"); trainUni.add("cornell"); trainUni.add("washington");
        trainUni.remove(UNI.toLowerCase());

        Hashtable<String, Integer> classCodes = new Hashtable<String, Integer>();
        Hashtable<String, Integer> uCodes = new Hashtable<String, Integer>();
        int classes[][]  = QueryWebKB.loadClasses(classCodes, uCodes);
        int labelCodes[] = {classCodes.get(classTarget1), classCodes.get(classTarget2)};
        int uniCodes[]   = {uCodes.get(trainUni.get(0)), uCodes.get(trainUni.get(1)), uCodes.get(trainUni.get(2))};

        //Part I: get the two tables (corresponding to labelCodes)

        List listDocs[] = new ArrayList[3], listIds[] = new ArrayList[3];
        listDocs[0] = new ArrayList(); listIds[0] = new ArrayList();
        QueryWebKB.filterClassWithIds(svdData, classes, labelCodes[0], uniCodes[0], listDocs[0], listIds[0]);
        listDocs[1] = new ArrayList(); listIds[1] = new ArrayList();
        QueryWebKB.filterClassWithIds(svdData, classes, labelCodes[0], uniCodes[1], listDocs[1], listIds[1]);
        listDocs[2] = new ArrayList(); listIds[2] = new ArrayList();
        QueryWebKB.filterClassWithIds(svdData, classes, labelCodes[0], uniCodes[2], listDocs[2], listIds[2]);
        int typeICodes[] = new int[listDocs[0].size() + listDocs[1].size() + listDocs[2].size()];
        int count = 0;
        for (int i = 0; i < uniCodes.length; i++)
            for (Iterator it = listIds[i].iterator(); it.hasNext();)
                typeICodes[count++] = ((Integer) it.next()).intValue();
        listDocs[0] = new ArrayList(); listIds[0] = new ArrayList();
        QueryWebKB.filterClassWithIds(svdData, classes, labelCodes[1], uniCodes[0], listDocs[0], listIds[0]);
        listDocs[1] = new ArrayList(); listIds[1] = new ArrayList();
        QueryWebKB.filterClassWithIds(svdData, classes, labelCodes[1], uniCodes[1], listDocs[1], listIds[1]);
        listDocs[2] = new ArrayList(); listIds[2] = new ArrayList();
        QueryWebKB.filterClassWithIds(svdData, classes, labelCodes[1], uniCodes[2], listDocs[2], listIds[2]);
        count = 0;
        int typeIICodes[] = new int[listDocs[0].size() + listDocs[1].size() + listDocs[2].size()];
        count = 0;
        for (int i = 0; i < uniCodes.length; i++)
            for (Iterator it = listIds[i].iterator(); it.hasNext();)
                typeIICodes[count++] = ((Integer) it.next()).intValue();

        //Part II: generate list of query links

        List<int[]> linked = new ArrayList<int[]>();
        List linkedTypeI = new ArrayList(), linkedTypeII = new ArrayList();
        List linkedTypeIDouble = new ArrayList(), linkedTypeIIDouble = new ArrayList();
        boolean typeIFlagged[] = new boolean[links.length], typeIIFlagged[] = new boolean[links.length];
        for (int i = 0; i < links.length; i++)
            typeIFlagged[i] = typeIIFlagged[i] = false;
        count = 0;
        for (int i = 0; i < typeICodes.length; i++) {
            if (links[typeICodes[i]] == null)
                continue;
            for (int j = 0; j < links[typeICodes[i]].length; j++)
                for (int k = 0; k < typeIICodes.length; k++)
                    if (links[typeICodes[i]][j] == typeIICodes[k]) {
                        int newLink[] = new int[2];
                        newLink[0] = typeICodes[i]; newLink[1] = typeIICodes[k];
                        linked.add(newLink);
                        if (!typeIFlagged[newLink[0]]) {
                            linkedTypeI.add(bernoulliData[newLink[0]]);
                            linkedTypeIDouble.add(svdData[newLink[0]]);
                            typeIFlagged[newLink[0]] = true;
                        }
                        if (!typeIIFlagged[newLink[1]]) {
                            linkedTypeII.add(bernoulliData[newLink[1]]);
                            linkedTypeIIDouble.add(svdData[newLink[1]]);
                            typeIIFlagged[newLink[1]] = true;
                        }
                        count++;
                    }
        }
        System.out.println(" -- Total possible links of this type: " + linked.size());
        int linkedTypeIArray[][] = new int[linkedTypeI.size()][];
        for (int i = 0; i < linkedTypeI.size(); i++)
            linkedTypeIArray[i] = (int[]) linkedTypeI.get(i);
        int linkedTypeIIArray[][] = new int[linkedTypeII.size()][];
        for (int i = 0; i < linkedTypeII.size(); i++)
            linkedTypeIIArray[i] = (int[]) linkedTypeII.get(i);
        double linkedTypeIArrayDouble[][] = new double[linkedTypeIDouble.size()][];
        for (int i = 0; i < linkedTypeIDouble.size(); i++)
            linkedTypeIArrayDouble[i] = (double[]) linkedTypeIDouble.get(i);
        double linkedTypeIIArrayDouble[][] = new double[linkedTypeIIDouble.size()][];
        for (int i = 0; i < linkedTypeIIDouble.size(); i++)
            linkedTypeIIArrayDouble[i] = (double[]) linkedTypeIIDouble.get(i);

        int query[][] = new int[linked.size()][2];
        count = 0;
        for (Iterator it = linked.iterator(); it.hasNext();) {
            int pair[] = (int[]) it.next();
            query[count][0] = pair[0];
            query[count++][1] = pair[1];
        }

        //Part III: use classes to restrict the search

        boolean allowableTypeI[] = new boolean[svdData.length];
        for (int i = 0; i < svdData.length; i++)
            allowableTypeI[i] = false;
        for (int i = 0; i < svdData.length; i++) {
            if (classes[i][0] != 3 && classes[i][1] != uniCodes[0] && classes[i][1] != uniCodes[1] && classes[i][1] != uniCodes[2])
                allowableTypeI[i] = true;
        }
        boolean allowableTypeII[] = new boolean[svdData.length];
        for (int i = 0; i < svdData.length; i++)
            allowableTypeII[i] = false;
        for (int i = 0; i < svdData.length; i++)
            if (classes[i][0] != 3 && classes[i][1] != uniCodes[0] && classes[i][1] != uniCodes[1] && classes[i][1] != uniCodes[2])
                allowableTypeII[i] = true;


        //Part IV: do the actual search

        if (METHOD.equals("BSETS1") || METHOD.equals("BSETS2")) {
            doBayesianSetsSearch(classes, labelCodes, uniCodes, bernoulliData, links, numVarsBernoulli, fileNames, query);
            return;
        }

        if (METHOD.equals("RBSETS")) {
            RelationalBayesianSetsBC rbSets = new RelationalBayesianSetsBC(svdData, links, QueryWebKB.priorsName, c, r);
            java.util.Date date1 = new java.util.Date();
            int results[][] = rbSets.query(query, allowableTypeI, allowableTypeII);
            resultsReport("RELATIONAL BAYESIAN SETS", results, fileNames, labelCodes, classes);
            java.util.Date date2 = new java.util.Date();
            System.out.println("Started at " + date1.toString() + ",finished at " + date2.toString());
        }

        if (METHOD.equals("COS1") || METHOD.equals("COS2")) {
            RelationalBayesianSetsBC rbSets = new RelationalBayesianSetsBC(svdData, links, QueryWebKB.priorsName, c, r);
            int results2[][];
            if (METHOD.equals("COS1"))
                results2 = rbSets.queryByCosine(query, allowableTypeI, allowableTypeII);
            else {
                int maxInt = 0;
                for (int i = 0; i < bernoulliData.length; i++)
                    for (int j = 0; j < bernoulliData[i].length; j++)
                        if (bernoulliData[i][j] > maxInt)
                            maxInt = bernoulliData[i][j];
                maxInt++;
                results2 = rbSets.queryByCosine(query, allowableTypeI, allowableTypeII, bernoulliData, maxInt);
            }
            resultsReport("COSINE DISTANCE", results2, fileNames, labelCodes, classes);
        }
    }


    protected static int[] getSparseIntersection(int input1[], int input2[]) {
        List<Integer> intersect = new ArrayList<Integer>();

        for (int i = 0; i < input1.length; i++)
            for (int j = 0; j < input2.length; j++) {
                if (input2[j] > input1[i])
                    break;
                if (input2[j] == input1[i]) {
                    intersect.add(input2[j]);
                    break;
                }
            }

        int output[] = new int[intersect.size()];
        int o = 0;
        for (Integer i : intersect)
            output[o++] = i;
        return output;
    }

    protected static void doBayesianSetsSearch(int classes[][], int labelCodes[], int uniCodes[], int bernoulliData[][],
                                               int links[][], int numVarsBernoulli, List<String> fileNames, int query[][])
                                               throws java.io.IOException
    {
        int totalNumVars;
        if (METHOD.equals("BSETS1"))
            totalNumVars = 3 * numVarsBernoulli;
        else
            totalNumVars = 2 * numVarsBernoulli;

        //Set empirical prior
        BayesianSets bSetsBackground = new BayesianSets(bernoulliData, numVarsBernoulli, true);
        double alpha[] = bSetsBackground.getAlpha();
        double beta[] = bSetsBackground.getBeta();
        double bigAlpha[] = new double[totalNumVars];
        double bigBeta[] = new double[totalNumVars];
        if (METHOD.equals("BSETS1")) {
            List<int[]> allLinked = new ArrayList<int[]>();
            for (int i = 0; i < links.length; i++) {
                int v1 = i;
                if (classes[i][0] == 3)
                    continue;
                for (int j = 0; j < links[i].length; j++) {
                    int v2 = links[i][j];
                    if (classes[v2][0] == 3)
                        continue;
                    if (v1 == v2)
                        continue;
                    int intersect[] = getSparseIntersection(bernoulliData[v1], bernoulliData[v2]);
                    allLinked.add(intersect);
                }
            }
            int allLinkedArray[][] = new int[allLinked.size()][];
            for (int i = 0; i < allLinked.size(); i++)
                allLinkedArray[i] = allLinked.get(i);
            BayesianSets bSetsBackground2 = new BayesianSets(allLinkedArray, numVarsBernoulli, true);
            double alpha2[] = bSetsBackground2.getAlpha();
            double beta2[] = bSetsBackground2.getBeta();
            for (int i = 0; i < alpha.length; i++) {
                bigAlpha[i] = bigAlpha[alpha.length + i] = alpha[i];
                bigBeta[i]  = bigBeta[beta.length + i]   = beta[i];
                bigAlpha[2 * alpha.length + i]           = alpha2[i];
                bigBeta[2 * beta.length + i]             = beta2[i];
            }

        }
        else
            for (int i = 0; i < alpha.length; i++) {
                bigAlpha[i] = bigAlpha[alpha.length + i] = alpha[i];
                bigBeta[i] = bigBeta[beta.length + i] = beta[i];
            }

        List<int[]> allLinked = new ArrayList<int[]>();
        List<int[]> index = new ArrayList<int[]>();
        for (int i = 0; i < links.length; i++) {
            int v1 = i;
            if (!(classes[i][0] != 3 && classes[i][1] != uniCodes[0] && classes[i][1] != uniCodes[1] && classes[i][1] != uniCodes[2]))
                continue;
            for (int j = 0; j < links[i].length; j++) {
                int v2 = links[i][j];
                if (!(classes[v2][0] != 3 && classes[v2][1] != uniCodes[0] && classes[v2][1] != uniCodes[1] && classes[v2][1] != uniCodes[2]))
                    continue;
                if (v1 == v2)
                    continue;
                int newPair[], intersect[] = null;
                if (METHOD.equals("BSETS1")) {
                   intersect = getSparseIntersection(bernoulliData[v1], bernoulliData[v2]);
                   newPair = new int[bernoulliData[v1].length + bernoulliData[v2].length + intersect.length];
                }  else
                   newPair = new int[bernoulliData[v1].length + bernoulliData[v2].length];
                for (int k = 0; k < bernoulliData[v1].length; k++)
                    newPair[k] = bernoulliData[v1][k];
                for (int k = 0; k < bernoulliData[v2].length; k++)
                    newPair[bernoulliData[v1].length + k] = numVarsBernoulli + bernoulliData[v2][k];
                if (METHOD.equals("BSETS1"))
                    for (int k = 0; k < intersect.length; k++)
                        newPair[bernoulliData[v1].length + bernoulliData[v2].length + k] = 2 * numVarsBernoulli + intersect[k];
                allLinked.add(newPair);
                int pair[] = {v1, v2};
                index.add(pair);
            }
        }
        int allLinkedArray[][] = new int[allLinked.size()][];
        for (int i = 0; i < allLinked.size(); i++)
            allLinkedArray[i] = allLinked.get(i);

        BayesianSets bSets = new BayesianSets(allLinkedArray, totalNumVars, false);
        bSets.setHyperparameters(bigAlpha, bigBeta);

        int queryMarginalData[][] = new int[query.length][];
        for (int i = 0; i < query.length; i++) {
            int v1 = query[i][0], v2 = query[i][1];
            int intersect[] = null;
            if (METHOD.equals("BSETS1")) {
                intersect = getSparseIntersection(bernoulliData[v1], bernoulliData[v2]);
                queryMarginalData[i] = new int[bernoulliData[v1].length + bernoulliData[v2].length + intersect.length];
            } else
                queryMarginalData[i] = new int[bernoulliData[v1].length + bernoulliData[v2].length];
            for (int j = 0; j < bernoulliData[v1].length; j++)
                queryMarginalData[i][j] = bernoulliData[v1][j];
            for (int j = 0; j < bernoulliData[v2].length; j++)
                queryMarginalData[i][bernoulliData[v1].length + j] = numVarsBernoulli + bernoulliData[v2][j];
            if (METHOD.equals("BSETS1"))
                for (int j = 0; j < intersect.length; j++)
                     queryMarginalData[i][bernoulliData[v1].length + bernoulliData[v2].length + j] =
                                2 * numVarsBernoulli + intersect[j];
        }
        double results[][] = bSets.query(queryMarginalData);

        double hitPoints[] = new double[results.length];
        for (int i = 0; i < results.length; i++) {
            int pair[] = index.get((int) results[i][0]);
            if (i < 100) {
                System.out.println("----> Pair #" + (i + 1) +", score = " + results[i][1]);
                System.out.println("-" + fileNames.get(pair[0]));
                System.out.println("-" + fileNames.get(pair[1]));
            }
            if (pair[0] == pair[1]) {
                hitPoints[i] = 0;
                continue;
            }
            if (TASK.equals("SC")) {
                if (classes[pair[0]][0] == labelCodes[0] && classes[pair[1]][0] == labelCodes[1])
                    hitPoints[i]++;
            } else if (TASK.equals("FP")) {
                if (classes[pair[0]][0] == labelCodes[0] && classes[pair[1]][0] == labelCodes[1])
                    hitPoints[i]++;
                else if ((classes[pair[0]][0] == 5 || classes[pair[0]][0] == 6) && classes[pair[1]][0] == labelCodes[1])
                    hitPoints[i] += 0.5;
            }
        }
        double maxPoints = 0.;
        for (int i = 0; i < results.length; i++)
            maxPoints += hitPoints[i];
        System.out.println(); System.out.println("Maximum number of points: " + maxPoints);

        PrintWriter output = new PrintWriter(UNI.toLowerCase() + "-" + METHOD.toLowerCase() + "-" + TASK.toLowerCase() + ".log");
        System.out.println("---- PRECISION / RECALL FOR BAYESIAN SETS BERNOULLI");
        double recalled = 0;
        for (int i = 0; i < results.length; i++) {
            recalled += hitPoints[i];
            System.out.println(i + ": " + recalled / (i + 1) + "\t" + recalled / maxPoints);
            output.println(i + ": " + recalled / (i + 1) + "\t" + recalled / maxPoints);
        }
        output.close();
    }

    protected static void resultsReport(String title, int results[][], List<String> fileNames,
                                        int labelCodes[], int classes[][]) throws java.io.IOException {
        double hitPoints[] = new double[results.length];

        for (int v = 0; v < results.length; v++) {
            if (v < 100) {
                System.out.println("----> Pair #" + (v + 1));
                System.out.println("-" + fileNames.get(results[v][0]));
                System.out.println("-" + fileNames.get(results[v][1]));
            }
            if (results[v][0] == results[v][1]) {
                hitPoints[v] = 0;
                continue;
            }
            if (TASK.equals("SC")) {
                if (classes[results[v][0]][0] == labelCodes[0] && classes[results[v][1]][0] == labelCodes[1])
                   hitPoints[v] = 1;
            } else if (TASK.equals("FP")) {
                if (classes[results[v][0]][0] == labelCodes[0] && classes[results[v][1]][0] == labelCodes[1])
                   hitPoints[v] = 1;
               else if ((classes[results[v][0]][0] == 5 || classes[results[v][0]][0] == 6) && classes[results[v][1]][0] == labelCodes[1])
                   hitPoints[v] = 0.5;
            }
        }
        double maxPoints = 0.;
        for (int i = 0; i < results.length; i++)
            maxPoints += hitPoints[i];
        System.out.println(); System.out.println("Maximum number of points: " + maxPoints);

        PrintWriter output = new PrintWriter(UNI.toLowerCase() + "-" + METHOD.toLowerCase() + "-" + TASK.toLowerCase() + ".log");
        System.out.println("---- PRECISION / RECALL FOR " + title);
        double recalled = 0;
        for (int i = 0; i < results.length; i++) {
            recalled += hitPoints[i];
            System.out.println(i + ": " + recalled / (i + 1) + "\t" + recalled / maxPoints);
            output.println(i + ": " + recalled / (i + 1) + "\t" + recalled / maxPoints);
        }
        output.close();
    }

}
