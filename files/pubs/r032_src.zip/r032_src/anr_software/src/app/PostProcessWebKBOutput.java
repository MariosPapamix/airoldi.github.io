package analogy.app;

import java.io.BufferedReader;
import java.io.FileReader;

/**
 * This class generates summary statistics (area under the curve) of the output
 * of a run of QueryWebKB.
 */

public class PostProcessWebKBOutput {

    public static void main(final String[] argv) {
        System.out.println("WebKB: process output (AUC calculation)"); System.out.println("------");

        try {
            String uni[] = {"texas", "wisconsin", "cornell", "washington"};
            String method[] = {"rbsets", "bsets1", "bsets2", "cos1", "cos2"};
            String task[] = {"sc", "fp"};

            for (int t = 0; t < task.length; t++) {
                for (int u = 0; u < uni.length; u++) {
                    for (int m = 0; m < method.length; m++) {
                        double area = calculateArea(uni[u] + "-" + method[m] + "-" + task[t] + ".log");
                        if (area >= 0)
                            System.out.println(uni[u] + "-" + method[m] + "-" + task[t] + ": AUC = " + area);
                    }
                    System.out.println();
                }
                System.out.println("------");
            }

        } catch (java.io.IOException e) {
            System.out.println("ERROR WRITING FILE");
            System.out.println(e.getMessage());
        }
    }

    protected static double calculateArea(String fileName) throws java.io.IOException {
        double area = 0.;

        try {
            //System.out.println("Reading file " + fileName);
            BufferedReader file = new BufferedReader(new FileReader(fileName));
            String line = file.readLine();
            double precision = 0., recall = 0.;
            double previousPrecision, previousRecall;
            int count = 0;
            while (line != null && !line.equals("")) {
                String stat[];
                if (fileName.endsWith("txt"))
                    stat =line.split(" +");
                else
                    stat =line.split("\t| +");
                previousPrecision = precision; previousRecall = recall;
                if (stat.length == 2) {
                    precision = Double.valueOf(stat[0]);
                    recall = Double.valueOf(stat[1]);
                } else {
                    precision = Double.valueOf(stat[1]);
                    recall = Double.valueOf(stat[2]);
                }
                line = file.readLine();
                count++;
                if (count == 1)
                    continue;
                area += (previousPrecision + precision) * (recall - previousRecall) * 0.5;
            }
            file.close();
        } catch(java.io.FileNotFoundException e) {
            area = -1;
            //System.out.println("Warning! File not found: " + fileName);
        }

        return area;
    }
}
