package analogy.app;

import analogy.prediction.Logistic;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.PrintWriter;
import java.io.FileOutputStream;
import java.util.List;
import java.util.ArrayList;
import java.util.Random;

import cern.colt.matrix.impl.DenseDoubleMatrix2D;
import cern.colt.matrix.linalg.Algebra;
import cern.colt.matrix.DoubleMatrix2D;

/**
 * This class generates the WebKB files necessary for our tests. It starts from the already pre-processed file
 * ``webkb25.data'', which is a SVD projection (25 dimensions) of the ``raw'' data ``webkb.data'' (which is
 * itself a pre-processed file obtained from the original WebKB data through using the processing method described
 * in the Bayesian sets paper (Ghahramani and Heller, 2005).
 *
 * You need one argument: the seed for the random number generator (used in order to sample ``negatively linked''
 * pairs). In the experiments for the AOAS paper, we used the seed 19580427.
 *
 * Command line example (classes were stored in the ``..\classes'' directory):
 *
 * > java -cp .;weka.jar;colt.jar;..\classes -mx1200m analogy.app.ProcessWebKB 19580427
 */

public class ProcessWebKB {

    protected static String DIR = "webkb/";
    protected static String svdDataBaseName = "webkb25.data";
    protected static String svdDataPriorTraining = "webkb25.training";
    protected static String vocabularyName = "webkb.vocab";
    protected static String linksName = "webkb.links";
    protected static String filesName = "webkb.files";
    protected static String priorsName = "prior.webkb";

    public static void main(final String[] argv)
    {
        if (argv.length != 1)
            throw new RuntimeException("Usage: ProcessWebKB <seed>");

        long seed = Integer.parseInt(argv[0]);
        Random r = new Random(seed);

        double svdData[][] = loadSVDData();
        int    links[][] = loadLinksArray(svdData.length);

        generateMLEData(r, svdData, links, DIR + svdDataPriorTraining);
        buildPriorMean(DIR + svdDataPriorTraining);
        buildPriorCov(DIR + svdDataPriorTraining);

        System.out.println("Done!");
    }

    /**
     * Procedures to load the data.
     */

    protected static double[][] loadSVDData() {
        String fileName = DIR + svdDataBaseName;
        try {
            List<double[]> docList = new ArrayList<double[]>();
            BufferedReader file = new BufferedReader(new FileReader(fileName));
            String line = file.readLine();
            while (line != null && !line.equals("")) {
                String doc[] = line.trim().split(" +");
                double docDouble[] = new double[doc.length];
                for (int i = 0; i < doc.length; i++)
                    docDouble[i] = Double.parseDouble(doc[i]);
                docList.add(docDouble);
                line = file.readLine();
            }
            double dataArray[][] = new double[docList.size()][];
            for (int i = 0; i < dataArray.length; i++)
                dataArray[i] = docList.get(i);
            return dataArray;
        } catch(java.io.FileNotFoundException e) {
            System.out.println("Warning! File not found: " + fileName);
            System.exit(0);
        } catch(java.io.IOException e) {
            System.out.println("Warning! IOException: " + fileName);
            System.exit(0);
        }
        return null;
    }

    protected static int[][] loadLinksArray(int dataSize) {
        String fileName = QueryWebKB.DIR + QueryWebKB.linksName;
        int links[][] = new int[dataSize][];
        int totalNumberOfLinks = 0;
        try {
            BufferedReader file = new BufferedReader(new FileReader(fileName));
            for (int i = 0; i < dataSize; i++) {
                String line = file.readLine();
                if (line.equals("")) {
                    links[i] = new int[0];
                    continue;
                }
                String linkStr[] = line.split("\t");
                links[i] = new int[linkStr.length];
                for (int j = 0; j < linkStr.length; j++)
                    links[i][j] = Integer.valueOf(linkStr[j]).intValue();
                totalNumberOfLinks += links[i].length;
            }
        } catch(java.io.FileNotFoundException e) {
            System.out.println("Warning! File not found: " + fileName);
            System.exit(0);
        } catch(java.io.IOException e) {
            System.out.println("Warning! IOException: " + fileName);
            System.exit(0);
        }
        System.out.println("Total number of links = " + totalNumberOfLinks);
        return links;
    }

    /**
     * Generate the training data that is used to ``fit the prior.''
     */

    public static void generateMLEData(Random r, double data[][], int relations[][], String fileName) {
        int negProportion = 10;
        int numRelations = 0, numVars = data[0].length;
        for (int i = 0; i < data.length; i++)
            numRelations += relations[i].length;
        double relationalData[][] = new double[numRelations * (negProportion + 1)][];
        int newClasses[] = new int[numRelations * (negProportion + 1)];
        int count = 0;

        relationAddition:
        for (int i = 0; i < data.length; i++)
            for (int t  = 0; t < relations[i].length; t++) {
                newClasses[count] = 1;
                relationalData[count] = new double[3 * numVars]; //Pay attention if MLE includes an intercept or not
                for (int j = 0; j < numVars; j++)
                    relationalData[count][j] = data[i][j];
                for (int j = 0; j < numVars; j++)
                    relationalData[count][numVars + j] = data[relations[i][t]][j];
                double norm1 = 0., norm2 = 0.;
                for (int k = 0; k < numVars; k++) {
                    norm1 += data[i][k] * data[i][k];
                    norm2 += data[relations[i][t]][k] * data[relations[i][t]][k];
                }
                norm1 = Math.sqrt(norm1); norm2 = Math.sqrt(norm2);
                for (int j = 0; j < numVars; j++)
                    relationalData[count][2 * numVars + j] = data[i][j] * data[relations[i][t]][j] / (norm1 * norm2);
                count++;
                if (count == numRelations)
                    break relationAddition;
            }

        //Select negative points randomly by rejection sampling
        System.out.println("Building negative examples!");
        for (int i = numRelations; i < numRelations * (negProportion + 1); i++) {
            int p1 = r.nextInt(data.length);
            nextDraw:
            do {
                int p2 = r.nextInt(data.length);
                if (p1 == p2)
                    continue;
                for (int p = 0; p < relations[p1].length; p++)
                    if (relations[p1][p] == p2)
                        continue nextDraw;
                newClasses[i] = 0;
                relationalData[i] = new double[3 * numVars ];
                for (int j = 0; j < numVars; j++)
                    relationalData[i][j] = data[p1][j];
                for (int j = 0; j < numVars; j++)
                    relationalData[i][numVars + j] = data[p2][j];
                double norm1 = 0., norm2 = 0.;
                for (int k = 0; k < numVars; k++) {
                    norm1 += data[p1][k] * data[p1][k];
                    norm2 += data[p2][k] * data[p2][k];
                }
                norm1 = Math.sqrt(norm1); norm2 = Math.sqrt(norm2);
                for (int j = 0; j < numVars; j++)
                    relationalData[i][2 * numVars + j] = data[p1][j] * data[p2][j] / (norm1 * norm2);
                break;
            } while (true);
        }


        System.out.println("Generating completed training file...");
        try {
            PrintWriter dataWriter = new PrintWriter(new FileOutputStream(fileName));

            for (int i = 0; i < relationalData.length; i++) {
                dataWriter.print(newClasses[i] + "\t");
                for (int j = 0; j < 3 * numVars; j++)
                    dataWriter.print(relationalData[i][j] + "\t");
                dataWriter.println();
            }
            dataWriter.close();
        } catch (java.io.IOException e) {
            System.out.println("Warning! IOException");
            System.exit(0);
        }
    }

    /**
     * ``Fit'' the prior.
     */

    protected static void buildPriorMean0(String fileName) {
        try  {
            System.out.println("Reading file " + fileName);
            List<double[]> docList = new ArrayList<double[]>();
            List<int[]> classList = new ArrayList<int[]>();
            BufferedReader file = new BufferedReader(new FileReader(fileName));
            String line = file.readLine();
            while (line != null && !line.equals("")) {
                String doc[] = line.split("\t");
                double docD[] = new double[doc.length - 1];
                for (int i = 1; i < doc.length; i++)
                    docD[i - 1] = Double.valueOf(doc[i]);
                docList.add(docD);
                int newC[] = {Integer.valueOf(doc[0])};
                classList.add(newC);
                line = file.readLine();
            }
            double dataArray[][] = new double[docList.size()][];
            for (int i = 0; i < dataArray.length; i++)
                dataArray[i] = docList.get(i);
            int classArray[] = new int[classList.size()];
            for (int i = 0; i < classArray.length; i++)
                classArray[i] = classList.get(i)[0];

            int numVars = 75 + 1;

            Logistic logistic = new Logistic(dataArray, classArray, false);
            System.out.println("Fitting empirical prior...");
            logistic.train();
            double coeff[] = logistic.getParams();
            for (int i = 0; i < coeff.length; i++)
                coeff[i] = -coeff[i]; //Since Weka's default is to treat class 0 as the positive class

            System.out.println("Saving coefficients...");
            PrintWriter out = new PrintWriter("prior.webkb");
            for (int i = 1; i < numVars; i++) {
                out.println(coeff[i]);
                System.out.println(coeff[i]);
            }
            out.println(coeff[0]); System.out.println(coeff[0]); //Intercept should be the last one
            out.close();

        } catch (java.io.IOException e) {
            System.out.println("FILE ERROR. Quitting now...");
        }
    }

    protected static void buildPriorCov(String fileName) {
        try  {
            int numVars = 75 + 1;
            double cov[][] = new double[numVars][numVars];

            BufferedReader in = new BufferedReader(new FileReader(fileName));
            String line = null;
            int lineCount = 0;

            while (true) {
                System.out.println("Reading line " + lineCount);
                line = in.readLine();
                if (line == null)
                    break;
                line = line.trim();
                if (line.equals(""))
                    continue;
                if (!line.startsWith("1"))
                    break;
                lineCount++;
                String tokens[] = line.split(" +|\t+");
                double row[] = new double[tokens.length];
                for (int i = 1; i < numVars; i++)
                    row[i - 1] = Double.valueOf(tokens[i]);
                row[numVars - 1] = 1;
                for (int i = 0; i < numVars; i++)
                    for (int j = 0; j < numVars; j++)
                        cov[i][j] += row[i] * row[j];
            }

            PrintWriter out = new PrintWriter("prior.webkb.cov");
            for (int i = 0; i < numVars; i++) {
                for (int j = 0; j < numVars; j++)
                    out.print(cov[i][j] / lineCount + " ");
                out.println();
            }
            out.close();

        } catch (java.io.IOException e) {
            System.out.println("FILE ERROR. Quitting now...");
        }
    }


    protected static void buildPriorMean(String fileName) {
        try  {
            System.out.println("Reading file " + fileName);
            List<double[]> docList = new ArrayList<double[]>();
            List<int[]> classList = new ArrayList<int[]>();
            BufferedReader file = new BufferedReader(new FileReader(fileName));
            String line = file.readLine();
            while (line != null && !line.equals("")) {
                String doc[] = line.split("\t");
                double docD[] = new double[doc.length];
                for (int i = 1; i < doc.length; i++)
                    docD[i - 1] = Double.valueOf(doc[i]);
                docD[doc.length - 1] = 1.;
                docList.add(docD);
                int newC[] = {Integer.valueOf(doc[0])};
                classList.add(newC);
                line = file.readLine();
            }
            double dataArray[][] = new double[docList.size()][];
            for (int i = 0; i < dataArray.length; i++)
                dataArray[i] = docList.get(i);
            double classArray[] = new double[classList.size()];
            for (int i = 0; i < classArray.length; i++)
                classArray[i] = classList.get(i)[0];

            int numVars = 75 + 1;

            double coeff[] = mle(dataArray, classArray, 350.);

            System.out.println("Saving coefficients...");
            PrintWriter out = new PrintWriter("prior.webkb");
            for (int i = 0; i < numVars; i++) {
                out.println(coeff[i]);
                System.out.println(coeff[i]);
            }
            out.close();

        } catch (java.io.IOException e) {
            System.out.println("FILE ERROR. Quitting now...");
        }
    }

    protected static double[] mle(double X[][], double y[], double negWeight) {
        int numVars = X[0].length;
        int sampleSize = X.length;
        int maxIter = 15;

        for (int d = 0; d < y.length; d++)
            if (y[d] < 0.)
                y[d] = 0.;

        double pointWeight[] = new double[sampleSize];
        for (int d = 0; d < sampleSize; d++) {
            if (y[d] == 1)
                pointWeight[d] = 1.;
            else
                pointWeight[d] = negWeight;
        }

        double z[] = new double[sampleSize];
        double p[] = new double[sampleSize];
        double W[] = new double[sampleSize];
        double beta[] = new double[numVars];
        double XtW[][] = new double[numVars][sampleSize];
        double XtWX[][] = new double[numVars][numVars];
        double innerProd[] = new double[sampleSize];

        for (int v = 0; v < numVars; v++)
            beta[v] = 0.;
        for (int d = 0; d < sampleSize; d++) {
            innerProd[d] = 0.;
            for (int v = 0; v < numVars; v++)
                innerProd[d] += beta[v] * X[d][v];
        }

        System.out.println("Starting MLE...");
        double logLike = 0.;
        for (int d = 0; d < sampleSize; d++) {
            if (y[d] > 0)
               logLike -= pointWeight[d] * Math.log(1 + Math.exp(-innerProd[d]));
            else
               logLike -= pointWeight[d] * Math.log(1 + Math.exp(innerProd[d]));
            if (Double.isNaN(logLike))
                System.out.println("NaN here");
        }
        System.out.println("Log-likelihood (0) = " + logLike);

        double betaBackup[] = new double[beta.length];
        mainBetaIter:
        for (int i = 0; i < maxIter; i++) {
            System.arraycopy(beta, 0, betaBackup, 0, beta.length);
            for (int d = 0; d < sampleSize; d++) {
                p[d] = sigmoid(innerProd[d]);
                W[d] = p[d] * (1. - p[d]);
                z[d] = (y[d] - p[d]) / W[d];
                for (int v = 0; v < numVars; v++)
                    z[d] += X[d][v] * beta[v];
            }
            System.out.println("Stage 2");
            for (int v = 0; v < numVars; v++)
                for (int d = 0; d < sampleSize; d++)
                    XtW[v][d] = X[d][v] * W[d];
            System.out.println("Stage 3");
            for (int v1 = 0; v1 < numVars; v1++)
                for (int v2 = v1; v2 < numVars; v2++)
                     XtWX[v1][v2] = 0.;
            for (int d = 0; d < sampleSize; d++)
                for (int v1 = 0; v1 < numVars; v1++)
                    for (int v2 = v1; v2 < numVars; v2++)
                        XtWX[v1][v2] += pointWeight[d] * XtW[v1][d] * X[d][v2];
            for (int v1 = 0; v1 < numVars; v1++)
                for (int v2 = v1 + 1; v2 < numVars; v2++)
                    XtWX[v2][v1] = XtWX[v1][v2];

            double invXtWX[][] = inverse(XtWX);
            System.out.println("Stage 4");
            for (int v = 0; v < numVars; v++) {
                beta[v] = 0.;
                for (int v0 = 0; v0 < numVars; v0++)
                    for (int d = 0; d < sampleSize; d++)
                         beta[v] += pointWeight[d] * invXtWX[v0][v] * XtW[v0][d] * z[d];
            }

            System.out.println("Stage 5");
            for (int d = 0; d < sampleSize; d++) {
                innerProd[d] = 0.;
                for (int v = 0; v < numVars; v++)
                    innerProd[d] += beta[v] * X[d][v];
            }
            System.out.println("Stage 6");
            logLike = 0.;
            for (int d = 0; d < sampleSize; d++) {
                if (y[d] > 0)
                   logLike -= pointWeight[d] * Math.log(1 + Math.exp(-innerProd[d]));
                else
                   logLike -= pointWeight[d] * Math.log(1 + Math.exp(innerProd[d]));
                if (Double.isInfinite(logLike)) {
                    System.out.println("! Infinite");
                    beta = betaBackup;
                    break mainBetaIter;
                }
                if (Double.isNaN(logLike)) {
                    System.out.println("! NaN");
                    beta = betaBackup;
                    break mainBetaIter;
                }
            }
            System.out.println("Log-likelihood (" + (i + 1) + ") = " + logLike);
        }
        return beta;
    }

    protected static double sigmoid(double x) {
        return 1. / (1. + Math.exp(-x));
    }

    protected static double[][] inverse(double matrix[][]) {
        Algebra algebra = new Algebra();
        DoubleMatrix2D m = new DenseDoubleMatrix2D(matrix);
        DoubleMatrix2D result = algebra.inverse(m);
        return result.toArray();
    }

    public static double determinant(double[][] m) {
        return new Algebra().det(new DenseDoubleMatrix2D(m));
    }

}
