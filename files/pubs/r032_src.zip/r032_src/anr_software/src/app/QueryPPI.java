package analogy.app;

/**
 * QueryPPI: The analogical reasoning ranking system for Protein-protein interaction pairs.
 *
 * In order to use it, you will also need a 'validation_criteria' directory storing all the gold standard information.
 *
 * You need two arguments: the first is the seed for the random number generator, while the second is the name of the
 * gold standard dataset (GO, MIPS or KEGG classes). In the experiments for the AOAS paper, we used the seed 19580427.
 *
 * You will also have to have generated the processed data files and prior file. Run 'ProcessProteinAll' and
 * 'ProcessProteinMicroarray' first.
 *
 * Command line example (classes were stored in the ``..\classes'' directory):
 *
 * > java -cp .;weka.jar;colt.jar;..\classes -mx800m analogy.app.QueryPPI 19580427 MIPS
 *
 * Notice: if you want to run the experiment where we feed the whole PPI data to the RelationalBayesianSets method
 * (instead of microarray only), change the variable PRIORS_NAME to "prior.allppi.pair", change
 * POSITIVE_FILENAME to "positiveAllPPI.dat" and change NEGSMALL_FILENAME to "negSmallAllPPI.dat".
 */

import analogy.bsets.RelationalBayesianSetsPair;
import analogy.bsets.RelationalRandomSetsPair;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.File;
import java.io.PrintWriter;
import java.util.*;

public class QueryPPI  {

    private static int    DEFAULT_QUERY_SIZE = 15;
    private static int    MIN_QUERY_POP = 50;
    private static String GOLD_ID = "";
    private static String LINK_FILE = "";
    private static double DEFAULT_C;
    private static int    NEIGHBORHOOD_SIZE;

    private static String  PRIORS_NAME     = "prior.microarray.pair";
    private static String  PRIORS_NAME_ALL = "prior.allppi.pair";

    private static String  POSITIVE_FILENAME     = "positiveMicroarray.dat";
    private static String  POSITIVE_FILENAME_ALL = "positiveAllPPI.dat";
    private static String  NEGSMALL_FILENAME     = "negSmallMicroarray.dat";

    //private static String  PRIORS_NAME        = "prior.allppi.pair";
    //private static String  POSITIVE_FILENAME  = "positiveallppi.dat";
    //private static String  NEGSMALL_FILENAME  = "negSmallAllPPI.dat";

    private static boolean FIRST_HUNDRED = false;
    private static boolean VERBOSE = false;

    private static Random  r;

    public static void main(final String[] argv) {
        System.out.println("** Protein-protein interaction retrieval");
        System.out.println(" - Code by Ricardo Silva, University College London, 2009");
        System.out.println(" - First release: July 1st 2009");
        System.out.println(" - Last modification: July 1st 2009");
        System.out.println();

        if (argv.length != 2) {
            System.out.println("Usage: ProcessProteinMicroarray <seed> <gold standard>, where " +
                               "gold standard = GO, MIPS or KEGG");
            System.exit(0);
        }

        setConstants(argv[1]);

        //Initialize global random number generator
        r = new Random(Integer.parseInt(argv[0]));

        if (GOLD_ID.equals("GO"))
           queryGOTerms(DEFAULT_QUERY_SIZE);
        else if (GOLD_ID.equals("MIPS"))
           queryMIPSTerms(DEFAULT_QUERY_SIZE);
        else
           queryKeggTerms(DEFAULT_QUERY_SIZE);
    }

    protected static void setConstants(String dataId) {
        if (dataId.equals("GO")) {
            //Note: the gold standard GO always uses the link matrix MIPS in our setup.
            DEFAULT_C = 6416.;
            NEIGHBORHOOD_SIZE = 2;
            GOLD_ID   = "GO";
            LINK_FILE = "ppi/links/mips.links";
            return;
        }
        if (dataId.equals("MIPS")) {
            //Note: the gold standard MIPS always uses the link matrix MIPS in our setup.
            DEFAULT_C = 6416. * 1000;
            NEIGHBORHOOD_SIZE = 2;
            GOLD_ID   = "MIPS";
            LINK_FILE = "ppi/links/mips.links";
            return;
        }
        if (dataId.equals("KEGG")) {
            //Note: the gold standard KEGG always uses the link matrix KEGG in our setup.
            DEFAULT_C = 38019.;
            NEIGHBORHOOD_SIZE = 1;
            GOLD_ID   = "KEGG";
            LINK_FILE = "ppi/links/kegg.links";
            return;
        }
        throw new RuntimeException("Gold standard not recognized: use GO, MIPS or KEGG");
    }
    
    //------------------------------------------------------------------------------------------------------------------

    /**
     * Methods for printing output.
     */

    protected static void printQuery(int query[][], List<String> proteinClasses[], String proteinNames[]) {
        for (int i = 0; i < query.length; i++) {
            System.out.println("Query " + i +":");
            for (int p = 0; p < 2; p++) {
                System.out.print(" - " + proteinNames[query[i][p]] + " (");
                for (int j = 0; j < proteinClasses[query[i][p]].size() - 1; j++)
                    System.out.print(proteinClasses[query[i][p]].get(j) + ", ");
                System.out.println(proteinClasses[query[i][p]].get(proteinClasses[query[i][p]].size() - 1) + ")");
            }
        }
    }

    protected static void printQuery(int query[][], String proteinNames[]) {
        for (int i = 0; i < query.length; i++) {
            System.out.println("Query " + i +":");
            for (int p = 0; p < 2; p++)
                System.out.println(" - " + proteinNames[query[i][p]]);
        }
    }

    protected static void printQuery(int query[][], String proteinNames[], String fileName) {
        try {
            PrintWriter out = new PrintWriter(fileName);
            for (int i = 0; i < query.length; i++)
                out.println(proteinNames[query[i][0]] + " x " + proteinNames[query[i][1]]);
            out.close();
        } catch (java.io.IOException e) {
            throw new RuntimeException(e);
        }
    }

    protected static String reportName(String term, String algorithm) {
        String newTerm = term.replace(':', '_');
        return newTerm + "." + algorithm;
    }

    //------------------------------------------------------------------------------------------------------------------

    /**
     * Methods for reading data files (protein ids, features, link matrices and gold standards).
     */

    protected static Hashtable<String, Integer> readProteins() throws java.io.IOException {
        BufferedReader in = new BufferedReader(new FileReader("protein.ids.dat"));
        String line = in.readLine().trim();
        Hashtable<String, Integer> output = new Hashtable<String, Integer>();
        int countProtein = 0;

        while (true) {
            line = in.readLine();
            if (line == null)
                break;
            line = line.trim();
            if (line.equals(""))
                continue;

            output.put(line, countProtein++);
        }

        return output;
    }

    protected static String[] readReverseProteins() throws java.io.IOException {
        BufferedReader in = new BufferedReader(new FileReader("protein.ids.dat"));
        String line = in.readLine().trim();
        List<String> output = new ArrayList<String>();

        while (true) {
            line = in.readLine();
            if (line == null)
                break;
            line = line.trim();
            if (line.equals(""))
                continue;
            output.add(line);
        }

        String outputArray[] = new String[output.size()];
        for (int i = 0; i < output.size(); i++)
            outputArray[i] = output.get(i);
        return outputArray;
    }

    protected static double[][] readData(String fileName) throws java.io.IOException {
        BufferedReader in = new BufferedReader(new FileReader(fileName));
        String line = null;
        List<double[]> rows = new ArrayList<double[]>();

        while (true) {
            line = in.readLine();
            if (line == null)
                break;
            line = line.trim();
            if (line.equals(""))
                continue;
             String tokens[] = line.split(" +|\t+");
            double row[] = new double[tokens.length];
            for (int i = 0; i < tokens.length; i++)
                row[i] = Double.parseDouble(tokens[i]);
            rows.add(row);
        }

        double output[][] = new double[rows.size()][rows.get(0).length];
        for (int i = 0; i < rows.size(); i++)
            System.arraycopy(rows.get(i), 0, output[i], 0, rows.get(i).length);
        return output;
    }

    protected static List<int[][]> readLinks(Hashtable<String, Integer> proteinIds) throws java.io.IOException {
        int size = proteinIds.size();
        int numLinks = 0;
        List<Integer> setLinks[] = new ArrayList[size];
        List<Integer> setLinksReverse[] = new ArrayList[size];
        for (int i = 0; i < size; i++) {
            setLinks[i] = new ArrayList<Integer>();
            setLinksReverse[i] = new ArrayList<Integer>();
        }
        BufferedReader in = new BufferedReader(new FileReader(LINK_FILE));
        String line = null;
        int notFound = 0;
        while (true) {
            line = in.readLine();
            if (line == null)
                break;
            line = line.trim();
            if (line.equals(""))
                continue;
            String sub[] = line.split(" +|\t+");
            Integer p1 = proteinIds.get(sub[0]);
            Integer p2 = proteinIds.get(sub[1]);
            if (p1 == null || p2 == null) {
                notFound++;
                continue;
            }
            if (p1 < p2) {
                setLinks[p1].add(p2);
                setLinksReverse[p2].add(p1);
            }
            else {
                setLinks[p2].add(p1);
                setLinksReverse[p2].add(p1);
            }
            numLinks++;
        }
        in.close();
        System.out.println("TOTAL NUMBER OF LINKS = " + numLinks + "(ignoring " + notFound + ")");

        int links[][] = new int[size][], linksReverse[][] = new int[size][];
        for (int i = 0; i < size; i++) {
            links[i] = new int[setLinks[i].size()];
            int pos = 0;
            for (Integer key : setLinks[i])
                links[i][pos++] = key;
            linksReverse[i] = new int[setLinksReverse[i].size()];
            pos = 0;
            for (Integer key : setLinksReverse[i])
                linksReverse[i][pos++] = key;
        }
        List<int[][]> outputLinks = new ArrayList<int[][]>();
        outputLinks.add(links); outputLinks.add(linksReverse);
        return outputLinks;
    }

    protected static Hashtable<String, Set<Integer>> readGOTerms(Hashtable<String, Integer> proteinIds)
    throws java.io.IOException {
        BufferedReader readSlim = new BufferedReader(new FileReader("ppi/validation_criteria/GO_functional_slim.txt"));
        HashSet<String> slimGO = new HashSet<String>();
        String slimLine = readSlim.readLine();
        while (true) {
            slimLine = readSlim.readLine();
            if (slimLine == null)
                break;
            slimLine = slimLine.trim();
            if (slimLine.equals(""))
                continue;

            String tokens[] = slimLine.split(" +|\t+");
            slimGO.add(tokens[0]);
        }
        readSlim.close();


        Hashtable<String, Set<Integer>> output = new Hashtable<String, Set<Integer>>();

        for (int s = 0; s < 3; s++) {
            BufferedReader in = null;
            switch(s) {
                case 0:
                    in = new BufferedReader(new FileReader("ppi/validation_criteria/go_terms/annotation_matrix_BP")); break;
                case 1:
                    in = new BufferedReader(new FileReader("ppi/validation_criteria/go_terms/annotation_matrix_CC")); break;
                case 2:
                    in = new BufferedReader(new FileReader("ppi/validation_criteria/go_terms/annotation_matrix_MF")); break;
            }
            String line = in.readLine().trim();
            String goIds[] = line.split(" +|\t+");
            for (int i = 0; i < goIds.length; i++)
                output.put(goIds[i], new HashSet<Integer>());

            while (true) {
                line = in.readLine();
                if (line == null)
                    break;
                line = line.trim();
                if (line.equals(""))
                    continue;

                String tokens[] = line.split(" +|\t+");
                for (int i = 1; i < tokens.length; i++)
                    if (Integer.parseInt(tokens[i]) == 1 && proteinIds.keySet().contains(tokens[0]))
                        output.get(goIds[i - 1]).add(proteinIds.get(tokens[0]));
            }
            in.close();
        }
        Set<String> toRemove = new HashSet<String>();
        for (String key : output.keySet())
            if (!slimGO.contains(key))
               toRemove.add(key);
        for (String removable : toRemove)
            output.remove(removable);

        return output;
    }

    protected static Hashtable<String, Set<Integer>> readKEGGTerms(Hashtable<String, Integer> proteinIds)
    throws java.io.IOException {
        String directory = "ppi/validation_criteria/kegg2_pathways";
        File dir = new File(directory);
        String[] files = dir.list();

        Hashtable<String, Set<Integer>> output = new Hashtable<String, Set<Integer>>();

        for (int s = 0; s < files.length; s++) {
            BufferedReader in = new BufferedReader(new FileReader(directory + "/" + files[s]));
            output.put(files[s], new HashSet<Integer>());
            String line = null;
            while (true) {
                line = in.readLine();
                if (line == null)
                    break;
                line = line.trim();
                if (line.equals(""))
                    continue;
                if (proteinIds.get(line) != null)
                   output.get(files[s]).add(proteinIds.get(line));
            }
            in.close();
        }
        return output;
    }

    protected static Hashtable<String, Set<Integer>> readMIPSTerms(Hashtable<String, Integer> proteinIds)
    throws java.io.IOException {
        String directory = "ppi/validation_criteria/mips";
        BufferedReader in = new BufferedReader(new FileReader(directory + "/mipsCat.txt"));
        Hashtable<String, Set<Integer>> output = new Hashtable<String, Set<Integer>>();

        String line = null;
        do {
            do {
               line = in.readLine();
            } while (line != null && line.trim().length() == 0);
            if (line == null)
                break;
            String category = line.trim();
            category = category.replace('\"', '_');
            category = category.replace('\\', '_');
            category = category.replace('/', '_');
            category = category.replace('?', '_');
            category = category.replace('*', '_');
            output.put(category, new HashSet<Integer>());
            in.readLine(); in.readLine(); //skip two lines
            do {
                line = in.readLine();
                if (line == null || line.trim().length() == 0)
                    break;
                line = line.trim();
                if (line.endsWith("A")) //corrects for stupid mipsCat.txt inconsistency
                    line = line.substring(0, line.length() - 1) + "-A";
                if (line.endsWith("B"))
                    line = line.substring(0, line.length() - 1) + "-B";
                if (proteinIds.get(line) != null)
                   output.get(category).add(proteinIds.get(line));
            } while (true);
        } while (line != null);

        in.close();
        return output;
    }

    protected static Hashtable<Integer, Hashtable<Integer, Integer>> readRelationsIndex(Hashtable<String, Integer> proteinIds)
    throws java.io.IOException {
        int size = proteinIds.size();

        Hashtable<Integer, Hashtable<Integer, Integer>> output = new Hashtable<Integer, Hashtable<Integer, Integer>>();
        for (int i = 0; i < size; i++)
            output.put(i, new Hashtable<Integer, Integer>());
        BufferedReader in = new BufferedReader(new FileReader(LINK_FILE));
        String line = null;
        int lineCount = 0;

        while (true) {
            line = in.readLine();
            if (line == null)
                break;
            line = line.trim();
            if (line.equals(""))
                continue;
            String sub[] = line.split(" +|\t");
            Integer p1 = proteinIds.get(sub[0]);
            Integer p2 = proteinIds.get(sub[1]);
            if (p1 == null || p2 == null)
                continue;
            int p1Value = p1, p2Value = p2;
            Hashtable<Integer, Integer> table = output.get(p1Value);
            table.put(p2Value, lineCount);
            table = output.get(p2Value);
            table.put(p1Value, lineCount);
            lineCount++;
        }
        in.close();

        return output;
    }

    //------------------------------------------------------------------------------------------------------------------

    /**
     * Methods for generating random queries.
     */

    protected static List<List<int[]>> randomPairPartition(Random r, List<int[]> linked, int querySize) {
        List<List<int[]>> output = new ArrayList<List<int[]>>();
        List<int[]> remaining = new ArrayList<int[]>(linked);
        List<int[]> selected = new ArrayList<int[]>();

        for (int i = 0; i < querySize; i++) {
            int sel = r.nextInt(remaining.size());
            selected.add(remaining.get(sel));
            remaining.remove(sel);
        }

        output.add(selected); output.add(remaining);
        return output;
    }

    //------------------------------------------------------------------------------------------------------------------

    /**
     * Utilities for obtaining linking information.
     */

    protected static boolean isLinked(int p1, int p2, int links[][]) {
        int chosenLinks[], other;
        if (p1 < p2) {
            chosenLinks = links[p1];
            other = p2;
        } else {
            chosenLinks = links[p2];
            other = p1;
        }
        for (int i = 0; i < chosenLinks.length; i++)
            if (chosenLinks[i] == other)
                return true;
        return false;
    }

    protected static List<int[]> getLinkedTerms(Set<Integer> ids, int links[][]) {
        int items[] = new int[ids.size()];
        int countItems = 0;

        for (Integer item : ids)
            items[countItems++] = item;

        List<int[]> output = new ArrayList<int[]>();
        for (int i = 0; i < countItems; i++) {
            int p1 = items[i];
            nextItem:
            for (int j = i + 1; j < countItems; j++) {
                int p2 = items[j];
                if (isLinked(p1, p2, links)) {
                    int pair[] = {p1, p2};
                    output.add(pair);
                    continue nextItem;
                }
            }
        }

        return output;
    }

    protected static List<int[]> getLinkedTerms(Set<Integer> ids1, Set<Integer> ids2, int links[][]) {
        int items1[] = new int[ids1.size()], countItems1 = 0;
        int items2[] = new int[ids2.size()], countItems2 = 0;

        for (Integer item1 : ids1)
            items1[countItems1++] = item1;
        for (Integer item2 : ids2)
            items2[countItems2++] = item2;

        List<int[]> output = new ArrayList<int[]>();
        for (int i = 0; i < countItems1; i++) {
            int p1 = items1[i];
            nextItem:
            for (int j = 0; j < countItems2; j++) {
                int p2 = items2[j];
                if (ids1.contains(p2) && ids2.contains(p1) && p2 < p1)
                    continue; //Avoid duplicates
                if (isLinked(p1, p2, links)) {
                    int pair[] = {p1, p2};
                    output.add(pair);
                    continue nextItem;
                }
            }
        }
        return output;
    }

    protected static HashSet<Integer> findNeighbors(int links[][], int linksReversed[][], HashSet<Integer> set) {
        HashSet<Integer> output = new HashSet<Integer>();
        HashSet<Integer> newSet = new HashSet<Integer>();
        for (int item : set) {
            for (int i = 0; i < links[item].length; i++)
                newSet.add(links[item][i]);
            for (int i = 0; i < linksReversed[item].length; i++)
                newSet.add(linksReversed[item][i]);
        }
        set.addAll(newSet);
        return output;
    }

    //------------------------------------------------------------------------------------------------------------------

    /**
     * Utilities for filtering.
     *
     * Returns a vector, setting to true only those elements that are linked to v1 or v2
     * by a path of size nSize or less.
     *
     * Notice that the links here have to be 'double-indexed', i.e., edge Pi - Pj should be
     * indexed both in links[i] and links[j].
     */

    protected static boolean[] filterByNeighborhood(String proteins[], int set[][],
                                                    int links[][], int linksReversed[][], int nSize) {
        HashSet<Integer> allowed = new HashSet<Integer>();
        for (int i = 0; i < set.length; i++) {
            allowed.add(set[i][0]);
            allowed.add(set[i][1]);
        }
        for (int n = 0; n < nSize; n++)
            allowed.addAll(findNeighbors(links, linksReversed, allowed));

        boolean output[] = new boolean[proteins.length];
        for (int i = 0; i < proteins.length; i++)
            output[i] = false;
        for (int value : allowed)
            output[value] = true;
        System.out.println("Total number of proteins in the domain: " + allowed.size());
        return output;
    }


    //------------------------------------------------------------------------------------------------------------------

    /**
     * Main query methods.
     */

    protected static void queryGOTerms(int querySize) {
        try {
            System.out.println("Reading protein IDs...");
            Hashtable<String, Integer> proteinIds = readProteins();
            String proteins[] = readReverseProteins();
            System.out.println("Reading GO terms...");
            Hashtable<String, Set<Integer>> goTerms = readGOTerms(proteinIds);
            System.out.println("Reading pairs features...");
            double data[][] = readData(POSITIVE_FILENAME);
            double dataCosine[][] = readData(POSITIVE_FILENAME_ALL);
            double dataNeg[][] = readData(NEGSMALL_FILENAME);
            System.out.println("Reading links...");
            List<int[][]> allLinks = readLinks(proteinIds);
            Hashtable<Integer, Hashtable<Integer, Integer>> relationsIndex = readRelationsIndex(proteinIds);
            System.out.println("Starting queries...");
            runQueryBioTerms(querySize, proteins, goTerms, data, dataNeg, dataCosine, relationsIndex, allLinks.get(0), allLinks.get(1));
        } catch (java.io.IOException e) {
            System.out.println(e);
            System.out.println("ERROR READING INPUT FILES!");
            System.exit(0);
        }
    }

    protected static void queryKeggTerms(int querySize) {
        try {
            System.out.println("Reading protein IDs...");
            Hashtable<String, Integer> proteinIds = readProteins();
            String proteins[] = readReverseProteins();
            System.out.println("Reading KEGG terms...");
            Hashtable<String, Set<Integer>> keggTerms = readKEGGTerms(proteinIds);
            System.out.println("Reading pairs features...");
            double data[][] = readData(POSITIVE_FILENAME);
            double dataCosine[][] = readData(POSITIVE_FILENAME_ALL);
            double dataNeg[][] = readData(NEGSMALL_FILENAME);
            System.out.println("Reading links...");
            List<int[][]> allLinks = readLinks(proteinIds);
            Hashtable<Integer, Hashtable<Integer, Integer>> relationsIndex = readRelationsIndex(proteinIds);
            System.out.println("Starting queries...");
            runQueryBioTerms(querySize, proteins, keggTerms, data, dataNeg, dataCosine, relationsIndex, allLinks.get(0), allLinks.get(1));
        } catch (java.io.IOException e) {
            System.out.println(e);
            System.out.println("ERROR READING INPUT FILES!");
            System.exit(0);
        }
    }

    protected static void queryMIPSTerms(int querySize) {
        try {
            System.out.println("Reading protein IDs...");
            Hashtable<String, Integer> proteinIds = readProteins();
            String proteins[] = readReverseProteins();
            System.out.println("Reading MIPS terms...");
            Hashtable<String, Set<Integer>> mipsTerms = readMIPSTerms(proteinIds);
            System.out.println("Reading pairs features...");
            double data[][] = readData(POSITIVE_FILENAME);
            double dataCosine[][] = readData(POSITIVE_FILENAME_ALL);
            double dataNeg[][] = readData(NEGSMALL_FILENAME);
            System.out.println("Reading links...");
            List<int[][]> allLinks = readLinks(proteinIds);
            Hashtable<Integer, Hashtable<Integer, Integer>> relationsIndex = readRelationsIndex(proteinIds);
            System.out.println("Starting queries...");
            runQueryBioTerms(querySize, proteins, mipsTerms, data, dataNeg, dataCosine, relationsIndex, allLinks.get(0), allLinks.get(1));
        } catch (java.io.IOException e) {
            System.out.println(e);
            System.out.println("ERROR READING INPUT FILES!");
            System.exit(0);
        }
    }

    protected static void runQueryBioTerms(int querySize, String proteins[],
                                           Hashtable<String, Set<Integer>> bioTerms, double pairData[][], double pairNegData[][],
                                           double pairDataCosine[][],
                                           Hashtable<Integer, Hashtable<Integer, Integer>> relationsIndex,
                                           int links[][], int linksReversed[][]) {
        int count = 0;
        int hitBox = 10;
        int maxIter = 5;
        Date date1 = new Date();
        int exp_number = 1, max_exp = countQueryBioTerms(querySize, bioTerms, links);

        List<double[]> allResults = new ArrayList<double[]>();

        //Run a query for each possible bio term
        allPairs:
        for (String go1 : bioTerms.keySet()) {
            Set<Integer> goProteins1 = bioTerms.get(go1);
            for (String go2 : bioTerms.keySet()) {
                if (go1.compareTo(go2) == 1)
                   continue;

                Set<Integer> goProteins2 = bioTerms.get(go2);
                List<int[]> linked;
                if (go1.equals(go2))
                   linked = getLinkedTerms(goProteins1, links);
                else
                   linked = getLinkedTerms(goProteins1, goProteins2, links);
                if (linked.size() < MIN_QUERY_POP)
                    continue;
                String goCombined = "(" + go1 + ") x (" + go2 + ")";
                System.out.println("*** Experiment #" + exp_number++ + "/" + max_exp + " for term " + goCombined);

                for (int iter = 0; iter < maxIter; iter++) {
                    List<List<int[]>> partition = randomPairPartition(r, linked, querySize);
                    int query[][] = new int[partition.get(0).size()][];
                    for (int i = 0; i < query.length; i++)
                        query[i] = partition.get(0).get(i);
                    if (VERBOSE)
                        printQuery(query, proteins);
                    printQuery(query, proteins, reportName(goCombined, "query." + iter));

                    boolean allowedRow[] = new boolean[pairData.length];
                    for (int i = 0; i < allowedRow.length; i++)
                        allowedRow[i] = true;
                    boolean allowableTypeI[] = new boolean[proteins.length];
                    for (int i = 0; i < proteins.length; i++)
                        allowableTypeI[i] = true;
                    boolean allowableTypeII[] = new boolean[proteins.length];
                    for (int i = 0; i < proteins.length; i++)
                        allowableTypeII[i] = true;
                    boolean allowedByNeighbor[] = filterByNeighborhood(proteins, query, links, linksReversed, NEIGHBORHOOD_SIZE);
                    int numPossible = 0;
                    for (int p1 = 0; p1 < proteins.length; p1++)
                        for (int p2 = p1 + 1; p2 < proteins.length; p2++)
                            if (isLinked(p1, p2, links) && allowableTypeI[p1] && allowableTypeII[p2] &&
                                allowedByNeighbor[p1] && allowedByNeighbor[p2]) {
                                if ((goProteins1.contains(p1) && goProteins2.contains(p2)) ||
                                    (goProteins1.contains(p2) && goProteins2.contains(p1)))
                                    numPossible++;
                            }
                    System.out.println("Search space: " + numPossible + ", Population size: " + linked.size() + " (" + (100 * numPossible / (double) linked.size()) + "%)");
                    double newResults[] = new double[10];
                    newResults[8] = numPossible; newResults[9] = linked.size();
                    RelationalBayesianSetsPair rbSets = new RelationalBayesianSetsPair(proteins.length, pairData,
                                                            links, DEFAULT_C, PRIORS_NAME, relationsIndex, proteins, r);
                    RelationalBayesianSetsPair rbSets2 = new RelationalBayesianSetsPair(proteins.length, pairDataCosine,
                                                            links, DEFAULT_C, PRIORS_NAME_ALL, relationsIndex, proteins, r);
                    int resultsCosine[][] = rbSets2.queryByCosine(query, allowedByNeighbor, allowedByNeighbor, null, allowedRow);
                    if (trivialQuery(resultsCosine, query, goProteins1, goProteins2, allowableTypeI, allowableTypeII, allowedByNeighbor)) {
                        System.out.println("Result *> TRIVIAL");
                        for (int v = 0; v < 4; v++) {
                            newResults[v * 2] = 0;
                            newResults[v * 2 + 1] = 0;
                        }
                    } else {
                        newResults[0] = simpleResultsReport("Cosine", "*> COSINE DISTANCE", resultsCosine, proteins, query, goProteins1, goProteins2,
                                                             allowableTypeI, allowableTypeII, allowedByNeighbor, hitBox,
                                                             reportName(goCombined, "cosine." + iter));
                        newResults[4] = newResults[0] / ((double) numPossible - query.length);
                        int resultsNN[][] = rbSets2.queryByNearestNeighbors(query, allowedByNeighbor, allowedByNeighbor, null, allowedRow);
                        newResults[1] = simpleResultsReport("NN", "*> NEAREST NEIGHBOR DISTANCE", resultsNN, proteins, query, goProteins1, goProteins2,
                                                            allowableTypeI, allowableTypeII, allowedByNeighbor, hitBox,
                                                            reportName(goCombined, "nn." + iter));
                        newResults[5] = newResults[1] / ((double) numPossible - query.length);

                        RelationalRandomSetsPair rrSets = new RelationalRandomSetsPair(proteins.length, pairData, pairNegData,
                                                            links, PRIORS_NAME, relationsIndex, proteins, 1500, r);
                        int resultsRegression[][] = rrSets.query(query, allowedByNeighbor, allowedByNeighbor, null, allowedRow);
                        newResults[2] = simpleResultsReport("RandomRegression", "*> RANDOM REGRESSION", resultsRegression, proteins, query, goProteins1, goProteins2,
                                        allowableTypeI, allowableTypeII, allowedByNeighbor, hitBox,
                                        reportName(goCombined, "random." + iter));
                        newResults[6] = newResults[2] / ((double) numPossible - query.length);

                        int resultsBayesian[][] = rbSets.query(query, allowedByNeighbor, allowedByNeighbor, null, allowedRow);
                        newResults[3] = simpleResultsReport("BayesianRegression", "*> BAYESIAN RELATIONAL REGRESSION", resultsBayesian, proteins, query, goProteins1, goProteins2,
                                        allowableTypeI, allowableTypeII, allowedByNeighbor, hitBox,
                                        reportName(goCombined, "bayesian." + iter));
                        newResults[7] = newResults[3] / ((double) numPossible - query.length);
                    }
                    allResults.add(newResults);
                    System.out.println();
                    count++;
                }
            }
        }

        System.out.println("Total number of systems = " + count);
        System.out.println("COSINE\tNN\tREGRESSION\tB-REGRESSION\tCOSINE\tNN\tREGRESSION\tB-REGRESSION\tNUM_POSSIBLE\tPOPULATION\tCOVERAGE");
        int hit100Total = (int) (0.5 * allResults.get(0).length);
        for (int i = 0; i < allResults.size(); i++) {
            double results[] = allResults.get(i);
            for (int j = 0; j < hit100Total; j++)
                System.out.print((int) results[j] + "\t");
            for (int j = hit100Total; j < results.length; j++)
                System.out.print(results[j] + "\t");
            System.out.print((int) results[8] + "\t" + (int) results[9] + "\t" + results[8]/results[9]);
            System.out.println();
        }
        Date date2 = new Date();
        System.out.println("Started at " + date1.toString() + ",finished at " + date2.toString());
    }

    protected static int countQueryBioTerms(int querySize, Hashtable<String, Set<Integer>> bioTerms, int links[][]) {
        //Counts possible queries for each possible pair of bio terms
        int totalPairs = 0;
        for (String go1 : bioTerms.keySet()) {
            Set<Integer> goProteins1 = bioTerms.get(go1);
            for (String go2 : bioTerms.keySet()){
                if (go1.compareTo(go2) == 1)
                    continue;
                Set<Integer> goProteins2 = bioTerms.get(go2);
                List<int[]> linked;
                if (go1.equals(go2))
                   linked = getLinkedTerms(goProteins1, links);
                else
                   linked = getLinkedTerms(goProteins1, goProteins2, links);
                if (linked.size() <= querySize)
                    continue;
                if (linked.size() < MIN_QUERY_POP)
                    continue;
                totalPairs++;
            }
        }
        System.out.println("Total number of pairs: " + totalPairs);
        return totalPairs;
    }

    //------------------------------------------------------------------------------------------------------------------

    /**
     * Methods for summarizing and printing the results of the analysis.
     */

    protected static int simpleResultsReport(String method,
                                             String title, int results[][], String proteinNames[],
                                             int query[][], Set<Integer> validProteins1, Set<Integer> validProteins2,
                                             boolean allowableI[], boolean allowableII[],
                                             boolean allowedByNeighbor[],
                                             int hitBox, String fileName) {
       try {
           PrintWriter log = null, logHits = null;
           if (fileName != null) {
               log = new PrintWriter(fileName + ".ids");
               logHits = new PrintWriter(fileName + ".hits");
           }

           double hitPoints[] = new double[results.length];
           int    countable[] = new int[results.length];
           int    totalInQuery = 0;
           for (int v = 0; v < results.length; v++) {
               hitPoints[v] = 0; countable[v] = 0;
               boolean in = inQuery(query, results[v][0], results[v][1]);
               if (!allowableI[results[v][0]] || !allowableII[results[v][1]] ||
                   !allowedByNeighbor[results[v][0]] || !allowedByNeighbor[results[v][1]])
                   continue;
               if (VERBOSE) {
                   if (v < 100) {
                       System.out.println("----> Pair #" + (v + 1));
                       System.out.println(" - " + proteinNames[results[v][0]]);
                       System.out.println(" - " + proteinNames[results[v][1]]);
                   }
                   if (in)
                       System.out.println("IN QUERY! Position = " + v);
               }
               if (in) {
                   totalInQuery++;
                   continue;
               }
               if ((validProteins1.contains(results[v][0]) && validProteins2.contains(results[v][1])) ||
                   (validProteins2.contains(results[v][0]) && validProteins1.contains(results[v][1])))
                   hitPoints[v] = 1;
               countable[v] = 1;
           }
           double maxPoints = 0.;
           for (int i = 0; i < results.length; i++)
               if (countable[i] > 0)
                   maxPoints += hitPoints[i];
           if (VERBOSE) {
               System.out.println();
               System.out.println("---- PRECISION / RECALL FOR " + title);
           }
           double recalled = 0, counted = 0, area = 0.;
           double previousPrecision = 0, previousRecall = 0;
           int    hitTop = 0;
           for (int i = 0; i < results.length; i++) {
               //System.out.println("<< " + results[i][0] + ", " + results[i][1]);
               if (countable[i] == 1) {
                   recalled += hitPoints[i];
                   if (counted < hitBox)
                       hitTop += hitPoints[i];
                   double precision = recalled / (counted + 1);
                   double recall = recalled / maxPoints;
                   if (VERBOSE && (!FIRST_HUNDRED || counted < 100))
                       System.out.println(counted + ": " + precision + "\t" + recall);
                   if (fileName != null && counted < 100) {
                       log.println(proteinNames[results[i][0]] + " x " + proteinNames[results[i][1]]);
                       logHits.println((int) hitPoints[i]);
                   }
                   if (i > 0)
                      area += 0.5 * (previousPrecision + precision) * (recall - previousRecall);
                   previousPrecision = precision; previousRecall = recall;
                   counted++;
               }
           }
           if (VERBOSE)
               System.out.println("#In query: " + totalInQuery);
           System.out.println("AUC [" + method + "] = " + area +
                              " (Maximum number of points: " + maxPoints + ", population = " + (int) counted +
                              ", Hits in " + hitBox + ": " + hitTop + ")");
           if (fileName != null) {
               log.close();
               logHits.close();
           }
           return hitTop;
       } catch (java.io.IOException e) {
           throw new RuntimeException(e);
       }
    }

    protected static boolean inQuery(int query[][], int v1, int v2) {
        for (int q = 0; q < query.length; q++)
            if ((query[q][0] == v1 && query[q][1] == v2) || (query[q][0] == v2 && query[q][1] == v1))
                return true;
        return false;
    }

    protected static boolean trivialQuery(int results[][],
                                          int query[][], Set<Integer> validProteins1, Set<Integer> validProteins2,
                                          boolean allowableI[], boolean allowableII[], boolean allowedByNeighbor[]) {
        double numHit = 0;
        int    numCountable = 0;
        for (int v = 0; v < results.length; v++) {
            boolean in = inQuery(query, results[v][0], results[v][1]);
            if (in)
                continue;
            if (!allowableI[results[v][0]] || !allowableII[results[v][1]] ||
                !allowedByNeighbor[results[v][0]] || !allowedByNeighbor[results[v][1]])
                continue;
            if ((validProteins1.contains(results[v][0]) && validProteins2.contains(results[v][1])) ||
                (validProteins2.contains(results[v][0]) && validProteins1.contains(results[v][1])))
                numHit++;
            numCountable++;
        }
        return numHit == numCountable;
    }

}

